--[[source: https://v3rmillion.net/showthread.php?tid=1019429
Arsenal TintenFisch GUI by Serpex.
game: https://www.roblox.com/games/286090429/
best arsenal trolling gui.
]]
loadstring(game:HttpGet("https://raw.githubusercontent.com/NougatBitz/ArsenalHaxx/master/TintenFisch.lua"))();