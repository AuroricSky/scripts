--[[https://v3rmillion.net/showthread.php?tid=1010980, Phantom Forces OP GUI with Silent aim by A-003.
]]
loadstring(game:HttpGet("https://www.pastebin.com/raw/m57yfT6v"))()