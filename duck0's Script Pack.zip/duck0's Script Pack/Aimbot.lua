--[[https://v3rmillion.net/showthread.php?tid=980945, AimHot v8 (OPEN SOURCE UNIVERSAL AIMBOT) by herrtt.
]]
pcall(function()
   loadstring(game:HttpGet("https://raw.githubusercontent.com/Herrtt/AimHot-v8/master/Main.lua", true))()
end)