--[[https://v3rmillion.net/showthread.php?tid=1006273, Phantom Forces Chams by ArilisDev.
]]
getgenv().ESPSettings = {
     Color = Color3.fromRGB(255, 204, 255)
}
loadstring(game:HttpGet('https://arilis.dev/releases/pf_chams.lua', true))()