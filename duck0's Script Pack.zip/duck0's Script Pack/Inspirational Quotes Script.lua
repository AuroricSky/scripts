--[[source:https://robloxscripts.com/inspirational-quotes-script/
Inspirational Quotes Script by Isaiah#8027.
EVERY TIME YOU DIE IT WILL TRY AND INSPIRE YOU TO CONTINUE LMAO
put this in your autoexec folder or gay.
]]
--Death Messages (change these strings to anything u want)

_G.deathMessage = {
   "Better Luck Next Time!",
   "You Died!",
   "Dont Be Sad!",
   "Try Again!",
   "You'll Get It This Time!",
   "Maybe Next Time!",
   "At Least You've Tried!",
   "Dont Give Up!",
   "Try Harder Next Time!",
   "Always follow your dreams with confidence and conviction!",
   "Believe In Yourself!",
   "Never Give Up!",
   "Keep Pushing!",
   "Dont Be A Quitter!",
   "Dont Be Ashamed!",
   "Keep Trying!",
   "Without struggle, success has no value!"
}

loadstring(game:HttpGet('https://pastebin.com/raw/8yuKfAkV'))()