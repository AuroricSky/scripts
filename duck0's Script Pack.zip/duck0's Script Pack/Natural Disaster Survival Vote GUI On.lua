--[[vote for map enable:
]]
votemenu = game.Players.LocalPlayer.PlayerGui.MainGui.MapVotePage

votemenu.Visible=true