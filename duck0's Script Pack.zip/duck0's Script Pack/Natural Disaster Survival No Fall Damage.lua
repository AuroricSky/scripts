--[[no fall damage: 
]]
game.Players.LocalPlayer.Character.FallDamageScript:Destroy()