--[[source: https://v3rmillion.net/showthread.php?tid=985152
Bad Business GUI by parr0t.
game: https://www.roblox.com/games/3233893879/
]]
loadstring(game:HttpGet("https://pastebin.com/raw/DBxNsNqa", true))();