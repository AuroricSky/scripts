--[[https://v3rmillion.net/showthread.php?tid=1006991, Lucidity GUI by iiToxicity.
Game: https://www.roblox.com/games/142823291/
]]
loadstring(game:HttpGet('https://pastebin.com/raw/NwbndAwB'))()