--[[source: https://v3rmillion.net/showthread.php?tid=1019030
Arsenal Never End Game Script by Prestiged.
game: https://www.roblox.com/games/286090429/
]]
loadstring(game:HttpGet("https://pastebin.com/raw/1vTJz1LX", true))()