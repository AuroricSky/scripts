--https://v3rmillion.net/showthread.php?tid=986482
--https://v3rmillion.net/showthread.php?tid=986645

local timerbb = 30;
local ads_toggle = true;
local greet_toggle = true;

--skidded stuff lolololol
math.randomseed(tick()) --idk I guess yeah I am dumb lol
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
-- Instances:

local BibleBot = Instance.new("ScreenGui")
local main = Instance.new("ImageLabel")
local label = Instance.new("TextLabel")
local timer = Instance.new("TextBox")
local timeLabel = Instance.new("TextLabel")
local TextButton = Instance.new("TextButton")
local ads = Instance.new("TextLabel")
local ads_on = Instance.new("TextButton")
local ads_off = Instance.new("TextButton")
local mid = Instance.new("Frame")
local greet = Instance.new("TextLabel")
local greet_on = Instance.new("TextButton")
local greet_off = Instance.new("TextButton")

--Properties:

BibleBot.Name = "BibleBot"
BibleBot.Parent = game.CoreGui

main.Name = "main"
main.Parent = BibleBot
main.AnchorPoint = Vector2.new(0.5, 0.5)
main.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
main.BackgroundTransparency = 1.000
main.Position = UDim2.new(0.49999997, 0, 0.5, 0)
main.Size = UDim2.new(0, 500, 0, 300)
main.Image = "rbxassetid://3570695787"
main.ImageColor3 = Color3.fromRGB(15, 15, 15)
main.ScaleType = Enum.ScaleType.Slice
main.SliceCenter = Rect.new(100, 100, 100, 100)
main.SliceScale = 0.250
main.Active = true

label.Name = "label"
label.Parent = main
label.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
label.BackgroundTransparency = 1.000
label.BorderSizePixel = 0
label.Position = UDim2.new(0.300000012, 0, 0, 0)
label.Size = UDim2.new(0, 200, 0, 25)
label.Font = Enum.Font.SourceSansLight
label.Text = "BibleBot"
label.TextColor3 = Color3.fromRGB(255, 255, 255)
label.TextScaled = true
label.TextSize = 14.000
label.TextWrapped = true

timer.Name = "timer"
timer.Parent = main
timer.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
timer.BorderSizePixel = 0
timer.Position = UDim2.new(0.0799999982, 0, 0.13333334, 0)
timer.Size = UDim2.new(0, 60, 0, 30)
timer.Font = Enum.Font.SourceSansLight
timer.Text = "30"
timer.TextColor3 = Color3.fromRGB(255, 255, 255)
timer.TextScaled = true
timer.TextSize = 14.000
timer.TextWrapped = true

timeLabel.Name = "timeLabel"
timeLabel.Parent = timer
timeLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
timeLabel.BackgroundTransparency = 1.000
timeLabel.BorderSizePixel = 0
timeLabel.Position = UDim2.new(1.41666663, 0, 0, 0)
timeLabel.Size = UDim2.new(0, 375, 0, 30)
timeLabel.Font = Enum.Font.SourceSansLight
timeLabel.Text = "Delay between each ad."
timeLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
timeLabel.TextScaled = true
timeLabel.TextSize = 14.000
timeLabel.TextWrapped = true
timeLabel.TextXAlignment = Enum.TextXAlignment.Left

TextButton.Parent = timer
TextButton.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
TextButton.BorderSizePixel = 0
TextButton.Position = UDim2.new(5.5999999, 0, 0, 0)
TextButton.Size = UDim2.new(0, 100, 0, 30)
TextButton.Font = Enum.Font.SourceSansLight
TextButton.Text = "Apply"
TextButton.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton.TextScaled = true
TextButton.TextSize = 14.000
TextButton.TextWrapped = true
TextButton.MouseButton1Click:Connect(function()
    timerbb = timer
end)


ads.Name = "ads"
ads.Parent = main
ads.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ads.BackgroundTransparency = 1.000
ads.BorderSizePixel = 0
ads.Position = UDim2.new(0.150000021, 0, 0.333333343, 0)
ads.Size = UDim2.new(0, 100, 0, 30)
ads.Font = Enum.Font.SourceSansLight
ads.Text = "Ads (default on)"
ads.TextColor3 = Color3.fromRGB(255, 255, 255)
ads.TextScaled = true
ads.TextSize = 14.000
ads.TextWrapped = true

ads_on.Name = "ads_on"
ads_on.Parent = ads
ads_on.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
ads_on.BorderSizePixel = 0
ads_on.Position = UDim2.new(-0.5, 0, 1.16666663, 0)
ads_on.Size = UDim2.new(0, 75, 0, 30)
ads_on.Font = Enum.Font.SourceSansLight
ads_on.Text = "On"
ads_on.TextColor3 = Color3.fromRGB(255, 255, 255)
ads_on.TextScaled = true
ads_on.TextSize = 14.000
ads_on.TextWrapped = true
ads_on.MouseButton1Click:Connect(function()
    ads_toggle = true
end)

ads_off.Name = "ads_off"
ads_off.Parent = ads
ads_off.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
ads_off.BorderSizePixel = 0
ads_off.Position = UDim2.new(0.75000006, 0, 1.16666663, 0)
ads_off.Size = UDim2.new(0, 75, 0, 30)
ads_off.Font = Enum.Font.SourceSansLight
ads_off.Text = "Off"
ads_off.TextColor3 = Color3.fromRGB(255, 255, 255)
ads_off.TextScaled = true
ads_off.TextSize = 14.000
ads_off.TextWrapped = true
ads_off.MouseButton1Click:Connect(function()
    ads_toggle = false
end)

mid.Name = "mid"
mid.Parent = main
mid.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mid.Position = UDim2.new(0.49000001, 0, 0.233333334, 0)
mid.Size = UDim2.new(0, 10, 0, 230)

greet.Name = "greet"
greet.Parent = main
greet.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
greet.BackgroundTransparency = 1.000
greet.BorderSizePixel = 0
greet.Position = UDim2.new(0.649999976, 0, 0.333333343, 0)
greet.Size = UDim2.new(0, 100, 0, 30)
greet.Font = Enum.Font.SourceSansLight
greet.Text = "Greeting (default on)"
greet.TextColor3 = Color3.fromRGB(255, 255, 255)
greet.TextScaled = true
greet.TextSize = 14.000
greet.TextWrapped = true

greet_on.Name = "greet_on"
greet_on.Parent = greet
greet_on.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
greet_on.BorderSizePixel = 0
greet_on.Position = UDim2.new(-0.5, 0, 1.16666663, 0)
greet_on.Size = UDim2.new(0, 75, 0, 30)
greet_on.Font = Enum.Font.SourceSansLight
greet_on.Text = "On"
greet_on.TextColor3 = Color3.fromRGB(255, 255, 255)
greet_on.TextScaled = true
greet_on.TextSize = 14.000
greet_on.TextWrapped = true
greet_on.MouseButton1Click:Connect(function()
    greet_toggle = true
end)

greet_off.Name = "greet_off"
greet_off.Parent = greet
greet_off.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
greet_off.BorderSizePixel = 0
greet_off.Position = UDim2.new(0.75000006, 0, 1.16666663, 0)
greet_off.Size = UDim2.new(0, 75, 0, 30)
greet_off.Font = Enum.Font.SourceSansLight
greet_off.Text = "Off"
greet_off.TextColor3 = Color3.fromRGB(255, 255, 255)
greet_off.TextScaled = true
greet_off.TextSize = 14.000
greet_off.TextWrapped = true
greet_off.MouseButton1Click:Connect(function()
    greet_toggle = false
end)


--dragging Api made by me (P3rZ3r0 lol)
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local gui = main
local speed = 0.1

local dragging
local dragInput
local dragStart
local startPos

local function update(input)
	local delta = input.Position - dragStart
	local goal = {}
	goal.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
	local tweenInfo = TweenInfo.new(speed)
	local tween = TweenService:Create(gui, tweenInfo, goal)
	tween:Play()
end

gui.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = true
		dragStart = input.Position
		startPos = gui.Position
		
		input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragging = false
			end
		end)
	end
end)

gui.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
		dragInput = input
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if input == dragInput and dragging then
		update(input)
	end
end)
--End

--skidded from bbot itself okk
local is_agaisnt_furry = true
is_furry = function(Player)
    if not is_agaisnt_furry then return false end
    local furry_hat = {"rbxassetid://3908012443";"rbxassetid//188699722"}
    for _,v in pairs(Player.Character:GetChildren()) do
        if v.ClassName == "Accessory" then
            pcall(function()
                if v.Handle.SpecialMesh.MeshId == furry_hat[1] or furry_hat[2] then
                    return true
                else
                    return false
                end
            end)
        end
    end
end

--again skidded lmao
endpoint = "http://labs.bible.org/api/?passage=random&type=json"
getVerse = function()
    local response = HttpService:JSONDecode(game:HttpGet(endpoint))
    return
        response[1].bookname .. ": " .. response[1].chapter .. ":" .. response[1].verse .. " " .. response[1].text
end

--skidded again not sure why there is tick but I am too much not smart
local t = tick()
chat = function(content)
    if t - tick() < 0.70 then
        wait(1)
    end
    game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(content, "All")
    t = tick()
end

commands = {};
 
commands.verse = function()
    local bible = getVerse()
    if string.len(bible) > 200 then
        repeat
            game:GetService("RunService").Heartbeat:Wait()
            bible = getVerse()
        until string.len(bible) < 200
    end
    chat(bible)
end
 
commands.askgod = function()
    local ans = {
         "Yes"; "No"; "It is best for you not to know"; "Your question is beyond your mortal comprehension"; "Blasphemy! ask no more."; "I do not care to entertain your trivial question";
        "You should be ashamed of what you are asking"; "Perhaps"; "I have nothing to say about it"; "I refuse to answer that"; "This is not a question befit for me, ask another"; "Reask that question, it makes no sense";
        "A pity, made in my image yet couldn't ask a more reasonable question for me";"Such foul words, i am ashamed of creating you";"Think twice of what you ask of me";
        "What you are asking me is blasphemy! confess your sin to me or face eternal torment";"You exist to suffer, no further comment.";"I didn't set fire to Gommorah for you to ask such a foolish question!";"Your question is why Judgement Day will come for us sooner then before.";"This question is beneath me, ask another!";
    }
    chat(ans[math.random(#ans)])
end
 
commands.help = function()
     chat("!ask god [question] - Ask God a question | !verse - Study the holy bible | !help - Show this help menu | !confess [sin], confess your actions to God | !pray [prayer] pray for something")
    wait(0.5)
end
 
commands.confesion = function(Player,message)
 
   local ans = {"Your sin has been forgiven, rejoice!";"I am overjoyed you have acknowledged your sin, God shall forgive you.";"You are forgiven, be glad Jesus died for your sake.";"I can see your sin weighs heavily on you, God has forgiven you!";"This is a sin that can not be easily forgiven, i demand you say Glory To God 20 times!";"Your sin mocks the commandments put forth by God, 20 Holy Mary's!";
                 "Your blasphemy ends here, pray Our Father and Holy Mary 30 times each right now!";"Your actions disgust our Lord";"Satan, smite " .. Player.Name ..
                " down for " .. Player.Name .. " has dared to defy God himself."};
    chat(ans[math.random(#ans)])
end
 
commands.pray = function(Player,message)

   local possibleAns = {"Amen";"Your greed disgusts me, confess your sin so that i may judge you by typing !confess [describe your foul actions here]";"Your prayer will be answered, Hallelujuh!";"Your prayer has been rejected for blasphemy! type !confess [your sin here] for judgement.";"I understand your feelings, it shall be done soon";"What you ask will be done, be patient my son";"Your prayer will be granted, in time."}
    chat(possibleAns[math.random(#possibleAns)])
end
 

--too lazy to add blacklist add it maybe urself kkk
onPlayerChat = function(chat_type,recipient,message)
    message = string.lower(message)
    chat_type = nil
    if message:match(".*!ask.-god.*") then
        commands:askgod()
    elseif message:match(".*!verse.*") then
        commands:verse()
    elseif message:match(".*!help.*") then
        commands:help()
    elseif message:match(".*!pray.*") then
        commands.pray(recipient,message)
    elseif message:match(".*!confess.*") then
        commands.confesion(recipient,message)
    end
end

Players.PlayerChatted:Connect(onPlayerChat)


--don't mind if I do
Players.PlayerAdded:Connect(function(NewPlayer)
    local welcomeSentence = {
        "Greetings " .. NewPlayer.Name .. ", study the bible to further your blossoming faith by chatting !verse";
        "Welcome " .. NewPlayer.Name .. "! to Bibleblox! study the bible with upmost vigor by chatting !verse";
        "Welcome to the holiest place on roblox " .. NewPlayer.Name .. ". Study the bible as soon as possible by chatting !verse";
        "Feel free to ask any question to God by chatting !ask god [question]";
        "Welcome to the most christian place on roblox " .. NewPlayer.Name;
        function()
            if os.date("*t").hour > 12 and os.date("*t").hour < 18 then
                return "Welcome " .. NewPlayer.Name .. " to the afternoon bible study session. Open your bible by chatting !verse"
            elseif os.date("*t").hour > 18  or os.date("*t").hour < 5 then
                return "Welcome " .. NewPlayer.Name .. " to the night bible study session. Open your bible by chatting !verse"
            elseif os.date("*t").hour > 5  and os.date("*t").hour < 12 then
                return "Welcome " .. NewPlayer.Name .. " to the morning bible study session. Open your bible by chatting !verse"
            end
        end;
        function()
            if os.date("*t").hour > 12 and os.date("*t").hour < 18 then
                return "Gosh! You are late to to the afternoon bible study session. Open your bible by chatting !verse quickly!!"
            elseif os.date("*t").hour > 18  or os.date("*t").hour < 5 then
                return "I can't believe you are *THIS* late to the night bible study! Open the bible asap(chat !verse)"
            elseif os.date("*t").hour > 5  and os.date("*t").hour < 12 then
                return "Oh lord! You are late to the morning bible study session! Chat !verse to open the bible"
            end
        end;
        function()
            if os.date("*t").hour > 12 and os.date("*t").hour < 18 then
                return "God will not forgive you for making him wait " .. os.date("*t") - 18 .. " to listen your question(Chat !ask god to ask question) DONT MAKE GOD WASTE HIS TIME"
            elseif os.date("*t").hour > 18  or os.date("*t").hour < 5 then
                return "God will not forgive you for making him wait " .. os.date("*t") - 5 .. " to listen your question(Chat !ask god to ask question) DONT MAKE GOD WASTE HIS TIME"
            elseif os.date("*t").hour > 5  and os.date("*t").hour < 12 then
                return "God will not forgive you for making him wait " .. os.date("*t") - 5 .. " to listen your question(Chat !ask god to ask question) DONT MAKE GOD WASTE HIS TIME"
            end
        end;
    }
    for cycle,sentence in next,welcomeSentence do
        if greet_toggle == true then
            if cycle == math.random(#welcomeSentence) then
                if type(sentence) == "function" then
                    chat(sentence())
                else
                    chat(sentence)
                end
                break
            end
        end
    end
end)

ad = {
    "Greetings all, I am bible bot, I guide the masses towards realizing the true faith. Chat !help to know all the available commands for me";
    "I have come forth to bring the good news to all! Chat !verse to hear of it";
    "Do not commit sin or suffer for eternity in hell! Chat !help to know the availaible commands for bible bot";
    "Always remember to pray to God. Chat !pray [someone or something you want] to learn what He has in store for your prayer";
    "Remember to study the bible to further your love for God. type !verse to study a verse of the bible, Chat !help to know other commands";
    "Submit to the divine authority of God and learn more of the one true faith by typing !help to know all the availaible commands of bible bot"
}

coroutine.resume(coroutine.create(function()
    while wait() do
 
        if ads_toggle == true then
            chat(ad[math.random(#ad)])
            wait(timerbb)
        end
    end
end))