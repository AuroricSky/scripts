--[[https://robloxscripts.com/kat-new-updated-gui__trashed/, KAT GUI by ScriptSkidChina.
]]
loadstring(game:HttpGet(('https://raw.githubusercontent.com/mememasterboi/a-lot-of-scripts/master/Output%20(6).lua'),true))()
