--[[https://v3rmillion.net/showthread.php?tid=1010752, View A Player's Country by Sinis.
]]
-- [[ Variable Declarations ]] --

--// Services

local WorkspaceService = game:GetService("Workspace")
local PlayersService = game:GetService("Players")
local RunService = game:GetService("RunService")
local HttpService = game:GetService("HttpService")

--// Client

local Client = PlayersService.LocalPlayer
local Camera = WorkspaceService.CurrentCamera

--// Collection

local Codes = {}
local Listings = {}

-- [[ Function Declarations ]] --

local get_hidden_prop = get_hidden_prop or gethiddenproperty

local function CreateCountryListing(Player)
   local CountryCode = get_hidden_prop(Player, "CountryRegionCodeReplicate")
   local Country = Codes[CountryCode] or "Unknown Code: " .. CountryCode

   local Text = Drawing.new("Text")

   Text.Transparency = 1
   Text.Text = Country
   Text.Center = true
   Text.Color = Color3.new(1, 1, 1)

   Listings[Player] = {
       Text = Text
   }
end

local function UpdateListing(Listing, Player)
   local Text = Listing.Text

   local Character = Player.Character

   if (Character) then
       local Head = Character:FindFirstChild("Head")

       if (Head) then
           local CameraSize = Camera.ViewportSize

           local WorldPosition = Head.Position + Vector3.new(0, 3, 0)
           local Position, Visible = Camera:WorldToViewportPoint(WorldPosition)
           local Transparency = 1 - math.clamp(Position.Z / 25, 0, 1)

           Text.Visible = Visible
           Text.Position = Vector2.new(Position.X, Position.Y)
           Text.Size = 24
           Text.Transparency = Transparency
       end
   else
       Text.Visible = false
   end
end

-- [[ Init ]] --

do
   --// Generate CountryCode to Country Pairing

   local Body = game:HttpGet("http://country.io/names.json")
   local Info = HttpService:JSONDecode(Body)

   for Code, Country in pairs(Info) do
       Codes[Code] = Country
   end
end

do
   --// Create Country Listings

   local Players = PlayersService:GetPlayers()

   for _, Player in pairs(Players) do
       --if (Player == Client) then continue end

       CreateCountryListing(Player)
   end

   PlayersService.PlayerAdded:Connect(CreateCountryListing)
end

do
   --// Update Listings

   RunService.Heartbeat:Connect(function()
       for Player, Listing in pairs(Listings) do
           UpdateListing(Listing, Player)

           if (not Player) then
               Listing.Text.Visible = false
           end
       end
   end)
end