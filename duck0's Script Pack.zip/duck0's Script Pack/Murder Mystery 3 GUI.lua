--[[https://v3rmillion.net/showthread.php?tid=1004873, script by YarkYT
]]
loadstring(game:HttpGet("https://pastebin.com/raw/fmCwUC7p", true))()