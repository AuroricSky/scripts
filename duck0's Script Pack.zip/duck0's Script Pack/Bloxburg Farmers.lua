--[[source: https://v3rmillion.net/showthread.php?tid=1015882
Bloxburg Farmers by Averias.
game: https://www.roblox.com/games/185655149/
TO USE IT COMPLETE 1 ORDER THEN EXECUTE THE SCRIPT: https://i.gyazo.com/bd3b9301b2f8a830e658a017bfd37d17.mp4
lets hope my 25 robux doesn't go to waste this time after i got banned on my other account lol.
]]
loadstring(game.HttpGet(game, "https://pastebin.com/raw/SgzFf9XP")) ()