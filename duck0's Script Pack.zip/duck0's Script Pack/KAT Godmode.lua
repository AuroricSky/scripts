--[[https://v3rmillion.net/showthread.php?tid=1009076, KAT Godmode by null.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/vDxJ05y7", true))()