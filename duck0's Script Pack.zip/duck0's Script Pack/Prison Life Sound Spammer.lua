--[[https://v3rmillion.net/showthread.php?tid=1010633, FE Prison Life Sound Spammer by Exodots.
]]
warn([[

   Exodots#3784
   
   This script is will be updated soon (more efficient way of doing it)
   
]])

local spamSound
local hearSound
local p = game:GetService("Players").LocalPlayer
spamSound = true --Set this to false to return the function when executed (Can be useful for gui's pls give credit)
hearSound = true --Set this to false so you don't hear it but everyone else does

local function SpamSound()
   
if not spamSound then return end

for i,v in pairs(p.Character:WaitForChild("HumanoidRootPart"):GetChildren()) do
  if (v:IsA("Sound")) then
       
       if hearSound then
           
       v.Volume = math.huge

       v:Play()

       game.ReplicatedStorage:WaitForChild("SoundEvent"):FireServer(v)
       
       else
 
       v.Volume = math.huge

       game.ReplicatedStorage:WaitForChild("SoundEvent"):FireServer(v)
   
       end

  end
 
end

local punchSound = p.Character.Head.punchSound

if hearSound then

punchSound:Play()

punchSound.Volume = math.huge

game.ReplicatedStorage:WaitForChild("SoundEvent"):FireServer(punchSound)

else

punchSound.Volume = math.huge

game.ReplicatedStorage:WaitForChild("SoundEvent"):FireServer(punchSound)

end


end

while true do
   wait() --Put a number here if you want to delay the noise
   
   SpamSound()
end
