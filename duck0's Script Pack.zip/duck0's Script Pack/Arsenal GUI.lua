--[[source: https://robloxscripts.com/arsenal-new-overpowered-gui-for-summer-update/
Arsenal GUI by Serpex.
]]
loadstring(game:HttpGet("https://raw.githubusercontent.com/NougatBitz/ArsenalHaxx/master/Script"))();
