--[[https://v3rmillion.net/showthread.php?tid=1009145, Fencing Auto-heal by jacob.
game: https://www.roblox.com/games/12109643/Fencing
not god mode but semi-god so you can still die but this adds a layer of protection as long as you're not a noob.
]]
local hrp = game.Players.LocalPlayer.Character.HumanoidRootPart
local button = workspace.Button

game:GetService("RunService").RenderStepped:connect(function()
    if hrp.Parent:FindFirstChild("Fencing Mask") ~= nil then
        hrp.Parent:FindFirstChild("Fencing Mask"):Destroy()
    end
firetouchinterest(hrp, button, 0)
firetouchinterest(hrp, button, 1)
end)