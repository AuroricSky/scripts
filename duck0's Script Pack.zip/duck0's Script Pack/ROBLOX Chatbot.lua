--[[ roblox chat bot - Cleverbot - but in roblox. by vinidalvino, https://v3rmillion.net/showthread.php?tid=1004996
]]
loadstring(game:HttpGet("https://gist.githubusercontent.com/ViniDalvino/9f26fb2694d1f71398b783ded5ed8d79/raw/b598394f5491b58ebf8cf6082f8e9a47ea56040c/cleverbot.lua"))()