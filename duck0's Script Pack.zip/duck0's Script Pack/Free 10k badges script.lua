--[[https://v3rmillion.net/showthread.php?tid=1009437, Non-laggy Free 10k badges script by jimmo 1.
game:https://www.roblox.com/games/5166670285/10-066-Badge-Walk?refPageId=701c4771-0f68-4672-a752-1d6db90a45c7
]]
local plr = game:GetService("Players").LocalPlayer

local char = plr.Character

for i, v in pairs(workspace:GetChildren()) do
if tonumber(v.Name) ~= nil then
       firetouchinterest(char.HumanoidRootPart, v:FindFirstChildOfClass("Part"),0)
       firetouchinterest(char.HumanoidRootPart, v:FindFirstChildOfClass("Part"),1)
end
       

   
end
