--[[https://v3rmillion.net/showthread.php?tid=1007707, Big Paintball Autofarm by Jakekill871.
**PUT THIS IN YOUR AUTOEXEC FOLDER ITS OP**
ARSENAL PATCHED BUT BIG PAINTBALL WORKS.
SYNAPSE X ONLY.
discord support server: https://discord.gg/PDWq8un
]]
_G.on = true -- true or false
_G.Time = 5 -- *PATCHED* ARSENAL ONLY this edits the time it takes for it to check whether you are on the menu, i reccommend 5 but 2 is my computers speed. the lower it is the faster it leaves when the match is done. but the lower it is the more chance it will just constantly rejoin.
loadstring(game:HttpGet("https://raw.githubusercontent.com/Jakekill871/public-scripts/master/FPSAutofarmUsingCriShouxUI"))();
--[[
big paintball game link https://www.roblox.com/games/3527629287/NUKETOWN-BIG-Paintball
This runs CriShoux UI and I can say for a fact its super cool.
Big Paintball Does not rejoin if you are wondering why there are no rejoin settings for it.
it farms in the same lobby, if you want auto deploy set the pos.
print key can now only use v because I broke it on accident... I'll fix it later but im working on more games.
]]