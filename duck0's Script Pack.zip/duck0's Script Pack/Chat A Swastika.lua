loadstring(game:HttpGet("https://pastebin.com/raw/ahBKsjJ2",true))()
