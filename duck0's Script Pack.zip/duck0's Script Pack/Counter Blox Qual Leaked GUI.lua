--[[https://robloxscripts.com/counter-blox-qual-leaked-private-gui/, Counter Blox Qual Leaked GUI leaked by sir#0001.
i chose the raycasting one but there are two other ones from the link above.
]]
UI = loadstring(game:HttpGet("http://bloxxite.xyz/rgwergdsfgsdtrjhsdrth", true))()

local Settings = {
	Startsound = "Default",
	Hitsound = "Skeet",
	HitsoundEnabled = false,
	Hitmarker = false,
	HitmarkerTarget = false,
	DefaultBot = "Legit",
	AA = {
		Enabled = false,
		Pitch = 1,
		JSpeed = 0.1,
		JRange = 90,
		Direction = "None",
		Left = "Z",
		Back = "X",
		Right = "C",
		JDirection = "H",
		JRotation = "J",
		Invisible = false
	},
	Legit = {
		AimbotMode = "Enabled",
		DetectionMethod = "Closest to Crosshair",
		AimbotStyle = "Completely Silent",
		Shootbot = false,
		MinVisibleDamage = 0,
		MinAWDamage = 0,
		FOVlim = false,
		HookHitpart = false,
		OverrideDamage = false,
		Damage = 1,
		FOVpx = 50,
		Autowall = false,
		Aimkey = "LeftShift",
		Headshotchance = 20,
		Backtrack = false,
		BacktrackDelay = 50,
		BacktrackColor = Color3.new(1, 1, 1),
		BacktrackTransparency = 0.8,
		BacktrackRainbow = false,
		FOVCircle = false,
		FOVFilled = false,
		FOVColor = Color3.new(1, 1, 0),
		FOVTransparency = 0,
		FOVThickness = 1
	},
	Rage = {
		AimbotMode = "Enabled",
		DetectionMethod = "Closest to Crosshair",
		AimbotStyle = "Completely Silent",
		Shootbot = false,
		MinVisibleDamage = 0,
		MinAWDamage = 0,
		HookHitpart = false,
		OverrideDamage = false,
		Damage = 1,
		FOVlim = false,
		FOVpx = 50,
		Autowall = false,
		Aimkey = "LeftShift",
		Backtrack = false,
		BacktrackDelay = 50,
		BacktrackColor = Color3.new(1, 1, 1),
		BacktrackTransparency = 0.8,
		BacktrackRainbow = false,
		FOVCircle = false,
		FOVFilled = false,
		FOVColor = Color3.new(1, 0, 0),
		FOVTransparency = 0,
		FOVThickness = 1
	},
	AsusWalls = {
		Enabled = false,
		Transparency = 0.7,
		PartModifier = 5,
		IncludeUnwallbangable = true,
	},
	Fakeduck = false,
	VX = 2.5,
	VY = 2.5,
	VZ = 2.5,
	TriggerbotMode = "Disabled",
	TriggerbotDelay = 0,
	Triggerkey = "CapsLock",
	FOV = 70,
	BulletTracers = false,
	TracerThickness1 = 2,
	TracerThickness2 = 5,
	BulletTracerColor = Color3.new(1,1,1),
	BulletTracerTransparency = 0.7,
	ThirdpersonDistance = 7,
	NoFall = false,
	SkinChanger = false,
	AntiMolotov = false,
	Autohop = false,
	LegitStrafe = false,
	AutohopSpeed = 25,
	AutohopHitrate = 100,
	InstaRev = false,
	RevAnimate = false,
	ChatAlive = false,
	SpectatorUI = false,
	BetterScope = false,
	Instaplant = false,
	Antidefuse = false,
	Noclip = false,
	NoSleeves = false,
	NoGloves = false,
	NoFlash = false,
	Buymenu = false,
	LagSeverity = 6,
	FloodMessages = 100,
	Chat1 = "Qual > All",
	Killsay = false,
	Chat2 = "{} just got tapped lmao",
	Unhash = false,
	AllChat = false,
	ThirdpersonKey = "X",
	Spectatorkey = "RightAlt",
	Noclipkey = "Period",
	Antiaim = "Disabled",
	AntiaimDetection = "None",
	ArmsEnabled = false,
	ArmsMaterial = "ForceField",
	ArmsColor = Color3.new(1, 0.5, 0),
	ArmsTransparency = 0.7,
	GunEnabled = false,
	GunMaterial = "ForceField",
	GunColor = Color3.new(1, 0.5, 0),
	GunTransparency = 0.7,
	LockedOnTransparency = 0,
	Skybox = "None",
	ClockTime = 14,
	Fullbright = false,
	WireframeSmoke = false,
	RemoveSmoke = false,
	RemoveFlash = false,
	InfiniteCash = false,
	RemoveGrenadeLogic = false,
	RLimbs = false,
	InfNades = false,
	Blockhead = false,
	Blockhats = false,
	Naked = false,
	HideName = false,
	Name = "Qual User",
	Watermark = false,
	InnerChams = {
		Allies = {
			Render = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
			UseTeamColor = false,
			VisibleOnly = false
		},
		Enemies = {
			Render = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
			UseTeamColor = false,
			VisibleOnly = false
		}
	},
	OuterChams = {
		Allies = {
			Render = false,
			Color = Color3.new(0,1,0),
			Transparency = 0,
			UseTeamColor = false,
			VisibleOnly = false,
			Size = 0.35
		},
		Enemies = {
			Render = false,
			Color = Color3.new(1,0,0),
			Transparency = 0,
			UseTeamColor = false,
			VisibleOnly = false,
			Size = 0.35
		}
	},
	Nametags = {
		Allies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		},
		Enemies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		}
	},
	Healthbar = {
		Allies = {
			Enabled = false,
			Color = Color3.new(1,1,1)
		},
		Enemies = {
			Enabled = false,
			Color = Color3.new(1,1,1)
		}
	},
	Boxes = {
		Allies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		},
		Enemies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		}
	},
	WeaponText = {
		Allies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		},
		Enemies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		}
	},
	Tracers = {
		Allies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		},
		Enemies = {
			Enabled = false,
			Color = Color3.new(1,1,1),
			Transparency = 0,
		}
	},
	BombText = {
		Allies = {
			Enabled = false,
			Color =  Color3.new(0,0.5,1),
			Transparency = 0,
		},
		Enemies = {
			Enabled = false,
			Color =  Color3.new(1,0.5,0),
			Transparency = 0,
		}
	}
}

local readfile = readfile or function() end

local Order = {
	Blue = 11,
	Purple = 10, 
	Pink = 9, 
	Red = 8, 
	Knife = 7,
	Bundle = 6, 
	Retired = 5, 
	Contraband = 4, 
	Finite = 3, 
	Tournament = 2,
	UNKNOWN = 1
}

local lastPoint = nil
local lastPart = nil

local FESkins = {}

local Storage = {
	CameraCF = nil,
	Targets = {}
}

local SpectateEntries = {}

local bodyParts = {
	["FakeHead"] = "Head",
	["HeadHB"] = "Head",
	["UpperTorso"] = "UpperTorso",
	["LowerTorso"] = "LowerTorso",
	["LeftUpperArm"] = "LeftUpperArm",
	["RightUpperArm"] = "RightUpperArm",
	["RightLowerArm"] = "RightLowerArm",
	["LeftLowerArm"] = "LeftLowerArm",
	["LeftHand"] = "LeftHand",
	["RightHand"] = "RightHand",
	["LeftUpperLeg"] = "LeftUpperLeg",
	["RightUpperLeg"] = "RightUpperLeg",
	["LeftLowerLeg"] = "LeftLowerLeg",
	["RightLowerLeg"] = "RightLowerLeg",
	["LeftFoot"] = "LeftFoot",
	["RightFoot"] = "RightFoot"
}

local BacktrackThing = {}

local Services = {
	Players = game:GetService("Players"),
	RunService = game:GetService("RunService"),
	CoreGui = game:GetService("CoreGui"),
	StarterGui = game:GetService("StarterGui"),
	Lighting = game:GetService("Lighting"),
	UserInputService = game:GetService("UserInputService"),
	HttpService = game:GetService("HttpService"),
	ReplicatedStorage = game:GetService("ReplicatedStorage"),
	TweenService = game:GetService("TweenService"),
	Debris = game:GetService("Debris"),
	GuiService = game:GetService("GuiService"),
}

local JSONData

function pack(val)
	if typeof(val) == "Color3" then
		return {"breh", val.r, val.g, val.b}
	end
	if typeof(val) == "table" then
		for i,v in pairs(val) do
			val[i] = pack(v)
		end
	end
	return val
end

local function deepCopy(original)
    local copy = {}
    for k, v in pairs(original) do
        -- as before, but if we find a table, make sure we copy that too
        if type(v) == "table" then
            v = deepCopy(v)
        end
        copy[k] = v
    end
    return copy
end

function Save()
	local NS = pack(deepCopy(Settings))
	local JSONData = Services.HttpService:JSONEncode(NS)
	writefile("Qual.json", JSONData)
end

function bunpack(val)
	if typeof(val) == "table" and val[1] == "breh" then
		return Color3.new(val[2], val[3], val[4])
	end
	if typeof(val) == "table" then
		for i,v in pairs(val) do
			val[i] = bunpack(v)
		end
	end
	return val
end


pcall(function()
	JSONData = readfile("Qual.json")
end)
if JSONData then
	local LUAData = Services.HttpService:JSONDecode(JSONData)
	Settings = bunpack(LUAData)
	print("[QUAL]: Loading from save..")
else
	Save()
	print("[QUAL]: Creating new save data..")
end

local Local = {
	Player = Services.Players.LocalPlayer,
	Camera = workspace:FindFirstChildOfClass("Camera"),
  	PlayerGui = nil,
	Mouse = nil,
  	Game = nil
}

local Events = Services.ReplicatedStorage.Events

local Weapons = {
	Pistols = {"USP", "P2000", "Glock", "DualBerettas", "P250", "FiveSeven", "Tec9", "CZ", "DesertEagle", "R8"},
	SMGs = {"MP9", "MAC10", "MP7", "UMP", "P90", "Bizon"},
	Rifles = {"M4A4", "M4A1", "AK47", "Famas", "Galil", "AUG"},
	AWP = {"AWP"},
	Scout = {"Scout", "SG"},
	Autosnipers = {"G3SG1"},
	Heavies = {"M249", "Negev"},
	Shotguns = {"XM", "Nova", "MAG7", "SawedOff"},
	AllWeapons = {"USP","P2000","Glock","DualBerettas","P250","FiveSeven","Tec9","CZ","DesertEagle","R8","MP9","MAC10","MP7","UMP","P90","Bizon","M4A4","M4A1","AK47","Famas","Galil","AUG","Scout","SG","AWP","SCAR20","G3SG1","M249","Negev","XM","Nova","MAG7","SawedOff"},
	Types = {"Pistols", "SMGs", "Rifles", "AWP", "Autosnipers", "Scout", "Heavies", "Shotguns"},
	Path = Services.ReplicatedStorage:FindFirstChild("Weapons"),
}

local Materials = {
	"ForceField",
	"Plastic",
	"Wood",
	"Slate",
	"Concrete",
	"CorrodedMetal",
	"DiamondPlate",
	"Foil",
	"Grass",
	"Ice",
	"Marble",
	"Granite",
	"Brick",
	"Pebble",
	"Sand",
	"Fabric",
	"SmoothPlastic",
	"Metal",
	"WoodPlanks",
	"Cobblestone",
	"Neon",
	"Glass",
}

local Animations = {
	"Fire",
	"Fire2",
	"Reload",
	"Stab",
	"Reload1",
	"Reload2",
	"Inspect",
	"Apply",
	"Remove",
	"StopFire"
}

local Hitsounds = {
	TF2 = 3455144981,
	TF2_Squasher = 3466981613,
	TF2_Retro = 3466984142,
	TF2_Beepo = 3466987025,
	TF2_Percussion = 3466985670,
	TF2_Space = 3466982899,
	TF2_Vortex = 3466980212,
	TF2_Electro = 3458224686,
	TF2_Note = 3466988045,
	TF2_Panhit = 3431749479,
	Body = 3213738472,
	Body2 = 2729036768,
	Thud = 3213739706,
	Clink = 1347140027,
	Skeet = 3124869783
}

local HitsoundsTable = {
	"Skeet",
	"TF2",
	"TF2_Squasher",
	"TF2_Retro",
	"TF2_Beepo",
	"TF2_Percussion",
	"TF2_Space",
	"TF2_Vortex",
	"TF2_Electro",
	"TF2_Note",
	"TF2_Panhit",
	"Body",
	"Body2",
	"Thud",
	"Clink"
}

local Skyboxes = {
	["Alien Red (Nostalgia)"] = {
		SkyboxLf = "http://www.roblox.com/asset/?version=1&id=1012889",
		SkyboxBk = "http://www.roblox.com/asset/?version=1&id=1012890",
		SkyboxDn = "http://www.roblox.com/asset/?version=1&id=1012891",
		SkyboxFt = "http://www.roblox.com/asset/?version=1&id=1012887",
		SkyboxLf = "http://www.roblox.com/asset/?version=1&id=1012889",
		SkyboxRt = "http://www.roblox.com/asset/?version=1&id=1012888",
		SkyboxUp = "http://www.roblox.com/asset/?version=1&id=1014449",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Cloudy Skies"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=252760980",
		SkyboxBk = "http://www.roblox.com/asset/?id=252760981",
		SkyboxDn = "http://www.roblox.com/asset/?id=252763035",
		SkyboxFt = "http://www.roblox.com/asset/?id=252761439",
		SkyboxLf = "http://www.roblox.com/asset/?id=252760980",
		SkyboxRt = "http://www.roblox.com/asset/?id=252760986",
		SkyboxUp = "http://www.roblox.com/asset/?id=252762652",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Counter Strike City"] = {
		SkyboxLf = "rbxassetid://2240133550",
		SkyboxBk = "rbxassetid://2240134413",
		SkyboxDn = "rbxassetid://2240136039",
		SkyboxFt = "rbxassetid://2240130790",
		SkyboxLf = "rbxassetid://2240133550",
		SkyboxRt = "rbxassetid://2240132643",
		SkyboxUp = "rbxassetid://2240135222",
		StarCount = 3000,
		SunAngularSize = 0
	},
	["Dark City"] = {
		SkyboxLf = "rbxassetid://1424484951",
		SkyboxBk = "rbxassetid://1424486234",
		SkyboxDn = "rbxassetid://1424485998",
		SkyboxFt = "rbxassetid://1424485697",
		SkyboxLf = "rbxassetid://1424484951",
		SkyboxRt = "rbxassetid://1424484760",
		SkyboxUp = "rbxassetid://1424484510",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Earth"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=166510092",
		SkyboxBk = "http://www.roblox.com/asset/?id=166509999",
		SkyboxDn = "http://www.roblox.com/asset/?id=166510057",
		SkyboxFt = "http://www.roblox.com/asset/?id=166510116",
		SkyboxLf = "http://www.roblox.com/asset/?id=166510092",
		SkyboxRt = "http://www.roblox.com/asset/?id=166510131",
		SkyboxUp = "http://www.roblox.com/asset/?id=166510114",
		StarCount = 0,
		SunAngularSize = 21
	},
	["Mountains By Crykee"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=368390615",
		SkyboxBk = "http://www.roblox.com/asset/?id=368385273",
		SkyboxDn = "http://www.roblox.com/asset/?id=48015300",
		SkyboxFt = "http://www.roblox.com/asset/?id=368388290",
		SkyboxLf = "http://www.roblox.com/asset/?id=368390615",
		SkyboxRt = "http://www.roblox.com/asset/?id=368385190",
		SkyboxUp = "http://www.roblox.com/asset/?id=48015387",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Old Skybox"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=15437157",
		SkyboxBk = "http://www.roblox.com/asset/?id=15436783",
		SkyboxDn = "http://www.roblox.com/asset/?id=15436796",
		SkyboxFt = "http://www.roblox.com/asset/?id=15436831",
		SkyboxLf = "http://www.roblox.com/asset/?id=15437157",
		SkyboxRt = "http://www.roblox.com/asset/?id=15437166",
		SkyboxUp = "http://www.roblox.com/asset/?id=15437184",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Purple Clouds"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=570557620",
		SkyboxBk = "http://www.roblox.com/asset/?id=570557514",
		SkyboxDn = "http://www.roblox.com/asset/?id=570557775",
		SkyboxFt = "http://www.roblox.com/asset/?id=570557559",
		SkyboxLf = "http://www.roblox.com/asset/?id=570557620",
		SkyboxRt = "http://www.roblox.com/asset/?id=570557672",
		SkyboxUp = "http://www.roblox.com/asset/?id=570557727",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Purple Nebula"] = {
		SkyboxLf = "http://www.roblox.com/asset/?id=159454286",
		SkyboxBk = "http://www.roblox.com/asset/?id=159454299",
		SkyboxDn = "http://www.roblox.com/asset/?id=159454296",
		SkyboxFt = "http://www.roblox.com/asset/?id=159454293",
		SkyboxLf = "http://www.roblox.com/asset/?id=159454286",
		SkyboxRt = "http://www.roblox.com/asset/?id=159454300",
		SkyboxUp = "http://www.roblox.com/asset/?id=159454288",
		StarCount = 0,
		SunAngularSize = 21
	},
	["Red Sky"] = {
		SkyboxLf = "http://www.roblox.com/Asset/?ID=401664881",
		SkyboxBk = "http://www.roblox.com/Asset/?ID=401664839",
		SkyboxDn = "http://www.roblox.com/Asset/?ID=401664862",
		SkyboxFt = "http://www.roblox.com/Asset/?ID=401664960",
		SkyboxLf = "http://www.roblox.com/Asset/?ID=401664881",
		SkyboxRt = "http://www.roblox.com/Asset/?ID=401664901",
		SkyboxUp = "http://www.roblox.com/Asset/?ID=401664936",
		StarCount = 0,
		SunAngularSize = 21
	},
	["Shrek"] = {
		SkyboxLf = "rbxassetid://198329363",
		SkyboxBk = "rbxassetid://198329363",
		SkyboxDn = "rbxassetid://198329363",
		SkyboxFt = "rbxassetid://198329363",
		SkyboxLf = "rbxassetid://198329363",
		SkyboxRt = "rbxassetid://198329363",
		SkyboxUp = "rbxassetid://198329363",
		StarCount = 0,
		SunAngularSize = 21
	},
	["Stormy Sky"] = {
		SkyboxLf = "http://www.roblox.com/asset/?version=1&id=1327363",
		SkyboxBk = "http://www.roblox.com/asset/?version=1&id=1327366",
		SkyboxDn = "http://www.roblox.com/asset/?version=1&id=1327367",
		SkyboxFt = "http://www.roblox.com/asset/?version=1&id=1327362",
		SkyboxLf = "http://www.roblox.com/asset/?version=1&id=1327363",
		SkyboxRt = "http://www.roblox.com/asset/?version=1&id=1327361",
		SkyboxUp = "http://www.roblox.com/asset/?version=1&id=1327368",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Twilight"] = {
		SkyboxLf = "rbxassetid://264909758",
		SkyboxBk = "rbxassetid://264908339",
		SkyboxDn = "rbxassetid://264907909",
		SkyboxFt = "rbxassetid://264909420",
		SkyboxLf = "rbxassetid://264909758",
		SkyboxRt = "rbxassetid://264908886",
		SkyboxUp = "rbxassetid://264907379",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Vaporwave Colors"] = {
		SkyboxLf = "rbxassetid://1417494402",
		SkyboxBk = "rbxassetid://1417494030",
		SkyboxDn = "rbxassetid://1417494146",
		SkyboxFt = "rbxassetid://1417494253",
		SkyboxLf = "rbxassetid://1417494402",
		SkyboxRt = "rbxassetid://1417494499",
		SkyboxUp = "rbxassetid://1417494643",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Vivid Skies"] = {
		SkyboxLf = "rbxassetid://2800902328",
		SkyboxBk = "rbxassetid://2800905936",
		SkyboxDn = "rbxassetid://2800905936",
		SkyboxFt = "rbxassetid://2800905116",
		SkyboxLf = "rbxassetid://2800902328",
		SkyboxRt = "rbxassetid://2800903916",
		SkyboxUp = "rbxassetid://2800906739",
		StarCount = 3000,
		SunAngularSize = 21
	},
	["Wasteland"] = {
		SkyboxLf = "rbxassetid://2046135392",
		SkyboxBk = "rbxassetid://2046134302",
		SkyboxDn = "rbxassetid://2046134976",
		SkyboxFt = "rbxassetid://2046135977",
		SkyboxLf = "rbxassetid://2046135392",
		SkyboxRt = "rbxassetid://2046136939",
		SkyboxUp = "rbxassetid://2046136551",
		StarCount = 3000,
		SunAngularSize = 21
	},
}

local SkyboxesTable = {
	"None",
	"Alien Red (Nostalgia)",
	"Cloudy Skies",
	"Counter Strike City",
	"Dark City",
	"Earth",
	"Mountains By Crykee",
	"Old Skybox",
	"Purple Clouds",
	"Purple Nebula",
	"Red Sky",
	"Shrek",
	"Stormy Sky",
	"Twilight",
	"Vaporwave Colors",
	"Vivid Skies",
	"Wasteland"
}

local fakeCFrame = nil

local Startsounds = {
	Default = 2668759868,
	Windows_95 = 265193160,
	Windows_XP = 4503772106,
	Windows_2000 = 130945434
}

local SkinClicked = nil

local function RandomCharGenerator(Length)
	local tb = {}
	for i = 1, Length do
		tb[i] = string.char(math.random(0, 100))
	end
	return table.concat(tb)
end

local Ace = Instance.new("ScreenGui", Services.CoreGui)
Ace.Name = RandomCharGenerator(20)

local DaFrame = Instance.new("Frame")
local UIListLayoute = Instance.new("UIListLayout")

DaFrame.Parent = Ace
DaFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DaFrame.BackgroundTransparency = 1.000
DaFrame.Position = UDim2.new(0.00506471563, 0, 0, 0)
DaFrame.Size = UDim2.new(0, 91, 0, 100)

UIListLayoute.Parent = DaFrame
UIListLayoute.SortOrder = Enum.SortOrder.LayoutOrder

Weapons.Old = Weapons.Path:Clone()

local Backtrack = Instance.new("Model", workspace)
local BacktrackSample = game:GetObjects("rbxassetid://4707836033")[1]

local S = Services.RunService.Stepped

Local.Mouse = Local.Player:GetMouse()
Local.PlayerGui = Local.Player.PlayerGui
Local.Game = getsenv(Local.PlayerGui.Client)
Local.Chat = getsenv(Local.PlayerGui.GUI.Main.Chats.DisplayChat)
Local.Game.resetinspect = true

function CreateFOV()
	local Circle = Drawing.new("Circle")
	S:connect(function()
		Circle.Position = Services.UserInputService:GetMouseLocation()
	end)
	return Circle
end

Storage["RageCircle"] = CreateFOV()
Storage["LegitCircle"] = CreateFOV()

local tsp = Vector2.new(Local.Camera.ViewportSize.X / 2, Local.Camera.ViewportSize.Y)

local Skybox = Instance.new("Sky")

function Whizz(v)
	Events.Whizz:FireServer(v, Weapons.Path.AWP)
end

function Rainbow(speed, saturation, brightness) 
	if speed == nil then
		speed = 3
	end
	if saturation == nil then
		saturation = 0.5
	end
	if brightness == nil then
		brightness = 1
	end
	return Color3.fromHSV(math.sin((tick() / (3/speed)) % 1), saturation, brightness) 
end

PlayerListInfo = {}

function GetDistanceSq(v1, v2) -- yeah optimization
	local a = v2.x - v1.x
	local b = v2.y - v1.y
    return (a*a) + (b*b)
end

function GetDistanceSq3(v1, v2) -- yeah optimization
	local a = v2.x - v1.x
	local b = v2.y - v1.y
	local c = v2.z - v1.z
    return a*a + b*b + c*c
end

local PlaySound = function(Sound, Time)
  	if Time == nil then
		Time = 0
	end
	spawn(function()
		local s = Instance.new("Sound")
		s.Parent = workspace
		s.SoundId = "rbxassetid://"..tostring(Sound)
		s.Volume = 4
		s:Play()
	  	wait(2)
	  	s:Destroy()
	end)
end

local AimbotFunctions = {}

AimbotFunctions.getAimCorners = function(obj, size)
	local corners = {
		Vector3.new(obj.X+size.X/2, obj.Y+size.Y/2, obj.Z), -- top left
		Vector3.new(obj.X-size.X/2, obj.Y+size.Y/2, obj.Z), -- top right

		Vector3.new(obj.X+size.X/2, obj.Y-size.Y/2, obj.Z), -- bottom left
		Vector3.new(obj.X-size.X/2, obj.Y-size.Y/2, obj.Z), -- bottom right
	}
	return corners
end

AimbotFunctions.getAimpoints = function(c)
	local aimpoints = {}
	if c:FindFirstChild("HeadHB") then
		table.insert(aimpoints, c.HeadHB.Position)
	end

	table.insert(aimpoints, c.UpperTorso.Position)

	table.insert(aimpoints, c.LeftUpperArm.Position)
	table.insert(aimpoints, c.RightUpperArm.Position)

	table.insert(aimpoints, c.LeftUpperLeg.Position)
	table.insert(aimpoints, c.RightUpperLeg.Position)

	return aimpoints
end

AimbotFunctions.getRealCameraVector = function(v)
	return v.HumanoidRootPart.CFrame.p + v.Humanoid.CameraOffset + Vector3.new(0, 1.5, 0)
end

AimbotFunctions.getCorners = function(obj, size)
	local corners = {
		Vector3.new(obj.X+size.X/2, obj.Y+size.Y/2, obj.Z+size.Z/2);
		Vector3.new(obj.X-size.X/2, obj.Y+size.Y/2, obj.Z+size.Z/2);
		
		Vector3.new(obj.X-size.X/2, obj.Y-size.Y/2, obj.Z-size.Z/2);
		Vector3.new(obj.X+size.X/2, obj.Y-size.Y/2, obj.Z-size.Z/2);
		
		Vector3.new(obj.X-size.X/2, obj.Y+size.Y/2, obj.Z-size.Z/2);
		Vector3.new(obj.X+size.X/2, obj.Y+size.Y/2, obj.Z-size.Z/2);
		
		Vector3.new(obj.X-size.X/2, obj.Y-size.Y/2, obj.Z+size.Z/2);
		Vector3.new(obj.X+size.X/2, obj.Y-size.Y/2, obj.Z+size.Z/2);
	}
	return corners
end

AimbotFunctions.VectorVisible = function(vector, v)
	local snapshot = Instance.new("Camera")
	snapshot.CFrame = CFrame.new(Local.Player.Character.Head.Position, vector)
	local ignorelist = {Local.Camera, snapshot, Local.Player.Character, v.Character, Backtrack}
	local parts = snapshot:GetPartsObscuringTarget({vector}, ignorelist)
	snapshot:Destroy()
	return #parts == 0
end

local HitboxPriorities = {
	Head = 4,
	Torso = 3,
	LeftArm = 2,
	RightArm = 2,
	LeftLeg = 1,
	RightLeg = 1
}

newclose = newcclosure or function(f) return f end

local ToSimplified = {
	["LeftHand"] = "LeftArm",
	["LeftLowerArm"] = "LeftArm",
	["LeftUpperArm"] = "LeftArm",
	["RightHand"] = "RightArm",
	["RightLowerArm"] = "RightArm",
	["RightUpperArm"] = "RightArm",
	["HeadHB"] = "Head",
	["UpperTorso"] = "Torso",
	["LowerTorso"] = "Torso",
	["LeftFoot"] = "LeftLeg",
	["LeftLowerLeg"] = "LeftLeg",
	["LeftUpperLeg"] = "LeftLeg",
	["RightFoot"] = "RightLeg",
	["RightLowerLeg"] = "RightLeg",
	["RightUpperLeg"] = "RightLeg"
}

local FromSimplified = {
	["LeftArm"] = "LeftLowerArm",
	["RightArm"] = "RightLowerArm",
	["Head"] = "HeadHB",
	["Torso"] = "UpperTorso",
	["LeftLeg"] = "LeftUpperLeg",
	["RightLeg"] = "RightUpperLeg"
}

AimbotFunctions.GetClosestToCrosshair = function(stat)
	local target = nil;
	local distance = math.huge
	for _,v in pairs(Services.Players:GetPlayers()) do
		if v:FindFirstChild("CameraCF") and v:FindFirstChild("Status") and v.Status:FindFirstChild("Alive") and v.Status.Alive.Value and v.Team ~= Local.Player.Team then
			local Mouse = Local.Mouse
			local stat = getStatus(v)
			if stat == "Friend" then return end
			stat = Settings[stat]
			local worldPoint = v.CameraCF.Value.p
			local vector, onScreen = Local.Camera:WorldToScreenPoint(worldPoint)
			local magnitude = GetDistanceSq(Vector2.new(Mouse.X, Mouse.Y), Vector2.new(vector.X, vector.Y))
			if onScreen and magnitude < distance and (magnitude < stat.FOVpx*stat.FOVpx or stat.FOVlim) then
				distance = magnitude
				target = v
			end
		end
	end
	return target
end

hammerunit2stud = 0.0694

AimbotFunctions.SimulateShot = function(cf, c)
	local range
	local penetrationpower
	local gun = Local.Game.gun
	if gun:FindFirstChild("Range") then
		range = gun.Range.Value
	end
	if gun:FindFirstChild("Penetration") then
		penetrationpower = gun.Penetration.Value * 0.01
	end
	local firerate
	if gun:FindFirstChild("FireRate") then
		firerate = gun.FireRate.Value
	end
	if gun:FindFirstChild("Melee") then
		range = 64
		if Local.Game.Held2 == true then
			firerate = 1
			range = 48
		end
	end
	local tinsert = table.insert
	local hitlist = {
		workspace.Debris,
		Local.Player.Character,
		workspace.Ray_Ignore,
		Local.Camera,
		workspace.Map:WaitForChild("Clips"),
		workspace.Map:WaitForChild("SpawnPoints")
	}
	local crud = game.Players:GetPlayers()
	for i = 1, #crud do
		if crud[i].Name ~= Local.Player.Name and crud[i].Character and crud[i].Character:FindFirstChild("UpperTorso") then
			if crud[i] and crud[i].Character:FindFirstChild("HumanoidRootPart") then
				tinsert(hitlist, crud[i].Character.HumanoidRootPart)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Head") then
				tinsert(hitlist, crud[i].Character.Head)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat1") then
				tinsert(hitlist, crud[i].Character.Hat1)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat2") then
				tinsert(hitlist, crud[i].Character.Hat2)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat3") then
				tinsert(hitlist, crud[i].Character.Hat3)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat4") then
				tinsert(hitlist, crud[i].Character.Hat4)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat5") then
				tinsert(hitlist, crud[i].Character.Hat5)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat6") then
				tinsert(hitlist, crud[i].Character.Hat6)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat7") then
				tinsert(hitlist, crud[i].Character.Hat7)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat8") then
				tinsert(hitlist, crud[i].Character.Hat8)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat9") then
				tinsert(hitlist, crud[i].Character.Hat9)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat10") then
				tinsert(hitlist, crud[i].Character.Hat10)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat11") then
				tinsert(hitlist, crud[i].Character.Hat11)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat12") then
				tinsert(hitlist, crud[i].Character.Hat12)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat13") then
				tinsert(hitlist, crud[i].Character.Hat13)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat14") then
				tinsert(hitlist, crud[i].Character.Hat14)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Hat15") then
				tinsert(hitlist, crud[i].Character.Hat15)
			end
			if crud[i] and crud[i].Character:FindFirstChild("DKit") then
				tinsert(hitlist, crud[i].Character.DKit)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Gun") then
				tinsert(hitlist, crud[i].Character.Gun)
			end
			if crud[i] and crud[i].Character:FindFirstChild("Gun2") then
				tinsert(hitlist, crud[i].Character.Gun2)
			end
		end
	end
	local direction = Vector3.new()
	local Mouse = cf.p + cf.lookVector * 999
	direction = (CFrame.new(cf.p, Mouse)).lookVector.unit * range * hammerunit2stud
	if Local.Game.equipped ~= "melee" then
		direction = cf.lookVector.unit * range * hammerunit2stud
	end
	local RayCasted = Ray.new(cf.p, direction)
	local partpenetrated = 0
	local limit = 0
	local PartHit, PositionHit, NormalHit
	local partmodifier = 1
	local damagemodifier = 1
	repeat
		PartHit, PositionHit, NormalHit = workspace:FindPartOnRayWithIgnoreList(RayCasted, hitlist, false, true)
		if PartHit and PartHit.Parent then
			partmodifier = 1
			if PartHit.Material == Enum.Material.DiamondPlate then
				partmodifier = 3
			end
			if PartHit.Material == Enum.Material.CorrodedMetal or PartHit.Material == Enum.Material.Metal or PartHit.Material == Enum.Material.Concrete or PartHit.Material == Enum.Material.Brick then
				partmodifier = 2
			end
			if PartHit.Name == "Grate" or PartHit.Material == Enum.Material.Wood or PartHit.Material == Enum.Material.WoodPlanks or PartHit and PartHit.Parent and PartHit.Parent:FindFirstChild("Humanoid") then
				partmodifier = 0.1
			end
			if PartHit.Transparency == 1 or PartHit.CanCollide == false or PartHit.Name == "Glass" or PartHit.Name == "Cardboard" or PartHit:IsDescendantOf(workspace.Ray_Ignore) or PartHit:IsDescendantOf(workspace.Debris) or PartHit and PartHit.Parent and PartHit.Parent.Name == "Hitboxes" then
				partmodifier = 0
			end
			if PartHit.Name == "nowallbang" then
				partmodifier = 100
			end
			if PartHit:FindFirstChild("PartModifier") then
				partmodifier = PartHit.PartModifier.Value
			end
			local fakehit, Endposition = workspace:FindPartOnRayWithWhitelist(Ray.new(PositionHit + direction * 1, direction * -2), {PartHit}, true)
			local PenetrationDistance = (Endposition - PositionHit).magnitude
			PenetrationDistance = PenetrationDistance * partmodifier
			limit = math.min(penetrationpower, limit + PenetrationDistance)
			local wallbang = false
			if partpenetrated >= 1 then
				wallbang = true
			end
			if PartHit and PartHit.Parent and PartHit.Parent.Name == "Hitboxes" or PartHit and PartHit.Parent.className == "Accessory" or PartHit and PartHit.Parent.className == "Hat" or PartHit.Name == "HumanoidRootPart" and PartHit.Parent.Name ~= "Door" or PartHit.Name == "Head" and PartHit.Parent:FindFirstChild("Hostage") == nil then
			else
				if PartHit and PartHit:IsDescendantOf(c) and PartHit.Transparency < 1 or PartHit.Name == "HeadHB" then
					return PartHit, PositionHit, damagemodifier, wallbang
				end
			end
			if partmodifier > 0 then
				partpenetrated = partpenetrated + 1
			end
			damagemodifier = 1 - limit / penetrationpower
			if PartHit and PartHit.Parent and PartHit.Parent.Name == "Hitboxes" or PartHit and PartHit.Parent and PartHit.Parent.Parent and PartHit.Parent.Parent:FindFirstChild("Humanoid2") or PartHit and PartHit.Parent and PartHit.Parent:FindFirstChild("Humanoid2") or PartHit and PartHit.Parent and PartHit.Parent:FindFirstChild("Humanoid") and (1 > PartHit.Transparency or PartHit.Name == "HeadHB") and PartHit.Parent:IsA("Model") then
				table.insert(hitlist, PartHit.Parent)
			else
				table.insert(hitlist, PartHit)
			end
		end
	until PartHit == nil or limit >= penetrationpower or partpenetrated >= 4 or 0 >= damagemodifier
end

--[[
	if v.Status.Alive.Value and v.Team ~= Local.Player.Team then
		  	local head = v.Character[p]
		  	local worldPoint = head.Position
			local vector, onScreen = Local.Camera:WorldToScreenPoint(worldPoint)
			local magnitude = GetDistanceSq(Vector2.new(Local.Mouse.X, Local.Mouse.Y), Vector2.new(vector.X, vector.Y))
		  	if distance > magnitude and onScreen and (magnitude < math.pow(Settings.FOVpx, 2) or Settings.FOVlim) then
			  	distance = magnitude
			  	target = v
		  	end
	  	end
]]

AimbotFunctions.GetNearest = function()
	local target = nil;
	local distance = math.huge
	for _,v in pairs(Services.Players:GetPlayers()) do
		if v.Status.Alive.Value and v.Team ~= Local.Player.Team then
			local magnitude = GetDistanceSq3(Local.Player.Character.HumanoidRootPart.Position, v.Character.HumanoidRootPart.Position)
			if distance > magnitude then
				distance = magnitude
				target = v
			end
		end
	end
	return target
end

function doSelfChams()
	if Local.Camera:FindFirstChild("Arms") then
		if Settings.GunEnabled then
			for i,v in pairs(Local.Camera:FindFirstChild("Arms"):GetChildren()) do
				if v:IsA("BasePart") then
					v.Color = Settings.GunColor
					v.Material = Settings.GunMaterial
					v.Transparency = Settings.GunTransparency
				end
			end
		end
		if Settings.ArmsEnabled then
			if Local.Camera and Local.Camera:FindFirstChild("Arms") then
				for i,m in pairs(Local.Camera:FindFirstChild("Arms"):GetChildren()) do
					if m:IsA("Model") then 
						for a,v in pairs(m:GetDescendants()) do
							if v:IsA("BasePart") then 
								v.Color = Settings.ArmsColor
								v.Material = Settings.ArmsMaterial
								v.Transparency = Settings.ArmsTransparency
							end
						end
					end
				end
			end
		end
		for _,part in pairs (Local.Camera:FindFirstChild("Arms"):GetDescendants()) do
			if Settings.NoSleeves then
				if part.Name == "Sleeve" then
					if part:IsA("Motor6D") == false then
						part.Transparency = 1
					end
				end
			else
				if part.Name == "Sleeve" then
					if part:IsA("Motor6D") == false then
						part.Transparency = 0
					end
				end
			end
			if Settings.NoGloves then
				if part.Name == "Glove" then
					part.Transparency = 1
				end
			else
				if part.Name == "Glove" then
					part.Transparency = 0
				end
			end
			if Settings.NoGloves then
				if part.Name == "Glove" then
					part.Transparency = 1
				end
			else
				if part.Name == "Glove" then
					part.Transparency = 0
				end
			end
		end
	end
end

function isAlive(v)
	return v and v.Character and v.Character:FindFirstChild("Head") and v.Character:FindFirstChild("HumanoidRootPart")
end

local UIListLayout = Instance.new("UIListLayout")
local UIPadding = Instance.new("UIPadding")
local TT = Instance.new("Frame")
local Team = Instance.new("TextLabel")
local Username = Instance.new("TextLabel")
local Status = Instance.new("TextLabel")
local Age = Instance.new("TextLabel")

local FESkin = Instance.new("Frame")
local SkinUser = Instance.new("TextLabel")
local Rarity = Instance.new("TextLabel")
local SkinLabel = Instance.new("TextLabel")
local UsingLabel = Instance.new("TextLabel")

local UIListLayout_2 = Instance.new("UIListLayout")
local UIPadding_2 = Instance.new("UIPadding")
local SFrame = Instance.new("ScrollingFrame")
local OutfitScroll = Instance.new("ScrollingFrame")
local SkinScroll = Instance.new("ScrollingFrame")
local Back = Instance.new("Frame")
local OBack = Instance.new("Frame")
local SBack = Instance.new("Frame")
local UIListLayout_3 = Instance.new("UIListLayout")
local UIPadding_3 = Instance.new("UIPadding")
local UIGridLayout = Instance.new("UIGridLayout")
local Container = Instance.new("Frame")
--Properties:
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

UIPadding.PaddingBottom = UDim.new(0, 8)
UIPadding.PaddingLeft = UDim.new(0, 8)
UIPadding.PaddingRight = UDim.new(0, 8)
UIPadding.PaddingTop = UDim.new(0, 8)

FESkin.Name = "FESkin"
FESkin.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
FESkin.BorderColor3 = Color3.new(0, 0, 0)
FESkin.Position = UDim2.new(0.00346500333, 0, 0.00661594467, 0)
FESkin.Size = UDim2.new(1, 0, 0, 20)

UISkin = Instance.new("UIListLayout")
UISkin.Parent = FESkin
UISkin.FillDirection = Enum.FillDirection.Horizontal
UISkin.SortOrder = Enum.SortOrder.LayoutOrder

SkinLabel.Name = "SkinLabel"
SkinLabel.Parent = FESkin
SkinLabel.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
SkinLabel.BorderColor3 = Color3.new(0, 0, 0)
SkinLabel.LayoutOrder = 2
SkinLabel.Size = UDim2.new(0.333, 0, 1, 0)
SkinLabel.Font = Enum.Font.SourceSans
SkinLabel.Text = "Skin"
SkinLabel.TextColor3 = Color3.new(1, 1, 1)
SkinLabel.TextSize = 14

Rarity.Name = "Rarity"
Rarity.Parent = FESkin
Rarity.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
Rarity.BorderColor3 = Color3.new(0, 0, 0)
Rarity.Size = UDim2.new(0.333, 0, 1, 0)
Rarity.LayoutOrder = 3
Rarity.Font = Enum.Font.SourceSans
Rarity.Text = "Rarity"
Rarity.TextColor3 = Color3.new(1, 1, 1)
Rarity.TextSize = 14

UsingLabel.Name = "UsingLabel"
UsingLabel.Parent = FESkin
UsingLabel.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
UsingLabel.BorderColor3 = Color3.new(0, 0, 0)
UsingLabel.Size = UDim2.new(0.333, 0, 1, 0)
UsingLabel.LayoutOrder = 4
UsingLabel.Font = Enum.Font.SourceSans
UsingLabel.Text = "Using"
UsingLabel.TextColor3 = Color3.new(1, 1, 1)
UsingLabel.TextSize = 14


TT.Name = "TT"
TT.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
TT.BorderColor3 = Color3.new(0, 0, 0)
TT.Position = UDim2.new(0.00346500333, 0, 0.00661594467, 0)
TT.Size = UDim2.new(1, 0, 0, 20)

Team.Name = "Team"
Team.Parent = TT
Team.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
Team.BorderColor3 = Color3.new(0, 0, 0)
Team.Size = UDim2.new(0.300000012, 0, 1, 0)
Team.Font = Enum.Font.SourceSans
Team.LayoutOrder = 1
Team.Text = "Team"
Team.TextColor3 = Color3.new(1, 1, 1)
Team.TextSize = 14

Username.Name = "Username"
Username.Parent = TT
Username.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
Username.BorderColor3 = Color3.new(0, 0, 0)
Username.LayoutOrder = 2
Username.Size = UDim2.new(0.300000012, 0, 1, 0)
Username.Font = Enum.Font.SourceSans
Username.Text = "Username"
Username.TextColor3 = Color3.new(1, 1, 1)
Username.TextSize = 14

Status.Name = "Status"
Status.Parent = TT
Status.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
Status.BorderColor3 = Color3.new(0, 0, 0)
Status.Size = UDim2.new(0.200000003, 0, 1, 0)
Status.LayoutOrder = 3
Status.Font = Enum.Font.SourceSans
Status.Text = "Aimbot Status"
Status.TextColor3 = Color3.new(1, 1, 1)
Status.TextSize = 14

Age.Name = "Age"
Age.Parent = TT
Age.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
Age.BorderColor3 = Color3.new(0, 0, 0)
Age.Size = UDim2.new(0.200000003, 0, 1, 0)
Age.Font = Enum.Font.SourceSans
Age.Text = "Account Age"
Age.LayoutOrder = 4
Age.TextColor3 = Color3.new(1, 1, 1)
Age.TextSize = 14

UIListLayout_2.Parent = TT
UIListLayout_2.FillDirection = Enum.FillDirection.Horizontal
UIListLayout_2.SortOrder = Enum.SortOrder.LayoutOrder

UIPadding_2.Parent = TT
UIPadding_2.PaddingRight = UDim.new(0, 11)

SFrame.Name = "SFrame"
SFrame.BackgroundColor3 = Color3.new(0.0509804, 0.0509804, 0.0509804)
SFrame.BorderColor3 = Color3.new(0, 0, 0)
SFrame.Size = UDim2.new(1, 0, 0, 120)
SFrame.BottomImage = "rbxassetid://132155326"
SFrame.MidImage = "rbxassetid://132155326"
SFrame.ScrollBarThickness = 10
SFrame.TopImage = "rbxassetid://132155326"
SFrame.ScrollBarImageColor3 = Color3.fromRGB(66, 66, 66)

OutfitScroll.Name = "OutfitScroll"
OutfitScroll.BackgroundColor3 = Color3.new(0.0509804, 0.0509804, 0.0509804)
OutfitScroll.BorderColor3 = Color3.new(0, 0, 0)
OutfitScroll.Size = UDim2.new(1, 0, 1, 0)
OutfitScroll.BottomImage = "rbxassetid://132155326"
OutfitScroll.MidImage = "rbxassetid://132155326"
OutfitScroll.ScrollBarThickness = 10
OutfitScroll.TopImage = "rbxassetid://132155326"
OutfitScroll.ScrollBarImageColor3 = Color3.fromRGB(66, 66, 66)

SkinScroll.Name = "SkinScroll"
SkinScroll.BackgroundColor3 = Color3.new(0.0509804, 0.0509804, 0.0509804)
SkinScroll.BorderColor3 = Color3.new(0, 0, 0)
SkinScroll.Size = UDim2.new(1, 0, 1, 0)
SkinScroll.BottomImage = "rbxassetid://132155326"
SkinScroll.MidImage = "rbxassetid://132155326"
SkinScroll.ScrollBarThickness = 10
SkinScroll.TopImage = "rbxassetid://132155326"
SkinScroll.ScrollBarImageColor3 = Color3.fromRGB(66, 66, 66)

OBack.Name = "OBack"
OBack.Parent = OutfitScroll
OBack.BackgroundColor3 = Color3.new(0.0980392, 0.0980392, 0.0980392)
OBack.BorderSizePixel = 0
OBack.Size = UDim2.new(1, 0, 1, 0)

SBack.Name = "SBack"
SBack.Parent = SkinScroll
SBack.BackgroundColor3 = Color3.new(0.0980392, 0.0980392, 0.0980392)
SBack.BorderSizePixel = 0
SBack.Size = UDim2.new(1, 0, 1, 0)

SBackList = Instance.new("UIListLayout", SBack)
SBackList.SortOrder = Enum.SortOrder.LayoutOrder

UIGridLayout.Parent = OBack
UIGridLayout.CellPadding = UDim2.new(0,0,0,0)
UIGridLayout.CellSize = UDim2.new(0.3,0,0,200)

Back.Name = "Back"
Back.Parent = SFrame
Back.BackgroundColor3 = Color3.new(0.0980392, 0.0980392, 0.0980392)
Back.BorderSizePixel = 0
Back.Size = UDim2.new(1, 0, 1, 0)

UIListLayout_3.Parent = Back
UIListLayout_3.SortOrder = Enum.SortOrder.LayoutOrder

UIPadding_3.Parent = Back
UIPadding_3.PaddingRight = UDim.new(0, 11)

local SampleInfo = Instance.new("TextLabel")
SampleInfo.BackgroundTransparency = 1
SampleInfo.Size = UDim2.new(1, 0, 1/6, 0)
SampleInfo.Font = Enum.Font.Gotham
SampleInfo.TextScaled = true
SampleInfo.TextStrokeTransparency = 3/4
SampleInfo.TextColor3 = Color3.new(1,1,1)
SampleInfo.TextTransparency = 0

local Scope = Instance.new("Frame")
local ScopeY = Instance.new("Frame")
local ScopeX = Instance.new("Frame")
local Scope_2 = Instance.new("ImageLabel")
local Blur = Instance.new("ImageLabel")
local Blur_2 = Instance.new("ImageLabel")
local Frame1 = Instance.new("Frame")
local Frame2 = Instance.new("Frame")
local Frame3 = Instance.new("Frame")
local Frame4 = Instance.new("Frame")

Scope.Name = "Scope"
Scope.BackgroundColor3 = Color3.new(1, 1, 1)
Scope.BackgroundTransparency = 1
Scope.Size = UDim2.new(1, 0, 1, 0)
Scope.Visible = false

ScopeY.Parent = Scope
ScopeY.BackgroundColor3 = Color3.new(0, 0, 0)
ScopeY.BorderColor3 = Color3.new(0, 0, 0)
ScopeY.BorderSizePixel = 0
ScopeY.Position = UDim2.new(0.5, 0, -1, 0)
ScopeY.Size = UDim2.new(0, 2, 3, 0)

ScopeX.Parent = Scope
ScopeX.BackgroundColor3 = Color3.new(0, 0, 0)
ScopeX.BorderColor3 = Color3.new(0, 0, 0)
ScopeX.BorderSizePixel = 0
ScopeX.Position = UDim2.new(-1, 0, 0.5, -18)
ScopeX.Size = UDim2.new(3, 0, 0, 2)

Scope_2.Name = "Scope"
Scope_2.Parent = Scope
Scope_2.BackgroundColor3 = Color3.new(1, 1, 1)
Scope_2.Image = "rbxasset://textures/ui/GuiImagePlaceholder.png"

Blur.Name = "Blur"
Blur.Parent = Scope_2
Blur.BackgroundColor3 = Color3.new(1, 1, 1)
Blur.Image = "rbxasset://textures/ui/GuiImagePlaceholder.png"

Blur_2.Name = "Blur"
Blur_2.Parent = Blur
Blur_2.BackgroundColor3 = Color3.new(1, 1, 1)
Blur_2.Image = "rbxasset://textures/ui/GuiImagePlaceholder.png"

Frame1.Name = "Frame1"
Frame1.BackgroundColor3 = Color3.new(1, 1, 1)
Frame1.BackgroundTransparency = 1
Frame1.Size = UDim2.new(1, 0, 1, 0)
Frame1.Visible = false

Frame2.Name = "Frame2"
Frame2.BackgroundColor3 = Color3.new(1, 1, 1)
Frame2.BackgroundTransparency = 1
Frame2.Size = UDim2.new(1, 0, 1, 0)
Frame2.Visible = false

Frame3.Name = "Frame3"
Frame3.BackgroundColor3 = Color3.new(1, 1, 1)
Frame3.BackgroundTransparency = 1
Frame3.Size = UDim2.new(1, 0, 1, 0)
Frame3.Visible = false

Frame4.Name = "Frame4"
Frame4.BackgroundColor3 = Color3.new(1, 1, 1)
Frame4.BackgroundTransparency = 1
Frame4.Size = UDim2.new(1, 0, 1, 0)
Frame4.Visible = false

local ScopeStorage = {Scope, Frame1, Frame2, Frame3, Frame4}
local letters = {}

local WBack = Instance.new("Frame")
local eUIPadding = Instance.new("UIPadding")
local eUIListLayout = Instance.new("UIListLayout")

WBack.Name = "WBack"
WBack.Parent = Ace
WBack.AnchorPoint = Vector2.new(1, 0)
WBack.BackgroundColor3 = Color3.new(0.156863, 0.156863, 0.156863)
WBack.BorderColor3 = Color3.new(0.156863, 0.156863, 0.156863)
WBack.BorderSizePixel = 0
WBack.Position = UDim2.new(1, 0, 0.100000009, 0)
WBack.Size = UDim2.new(0, 424, 0, 30)
WBack.Visible = Settings.Watermark

eUIPadding.Parent = WBack
eUIPadding.PaddingLeft = UDim.new(0, 10)

for i = 1,59 do
	local _1 = Instance.new("TextLabel")
	_1.Name = "1"
	_1.Parent = WBack
	_1.TextTransparency = 1
	_1.BackgroundColor3 = Color3.new(1, 1, 1)
	_1.BackgroundTransparency = 1
	_1.Size = UDim2.new(0, 7, 1, 0)
	_1.Font = Enum.Font.Code
	_1.Text = "a"
	_1.TextColor3 = Color3.new(1, 1, 1)
	_1.TextSize = 14
	table.insert(letters, _1)
end

eUIListLayout.Parent = WBack
eUIListLayout.FillDirection = Enum.FillDirection.Horizontal
eUIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

local SpecF = Instance.new("Frame")
local LayoutF = Instance.new("UIListLayout")
local Top = Instance.new("Frame")
local Spec = Instance.new("TextLabel")
local OBSM = Instance.new("TextLabel")

SpecF.Parent = Ace
SpecF.BackgroundColor3 = Color3.new(1, 1, 1)
SpecF.BackgroundTransparency = 1
SpecF.Position = UDim2.new(0.0132528171, 0, 0.33205381, 0)
SpecF.Size = UDim2.new(0.12, 0, 0.232437596, 0)
SpecF.Visible = false

LayoutF.Parent = SpecF
LayoutF.SortOrder = Enum.SortOrder.LayoutOrder

Top.Name = "Top"
Top.Parent = SpecF
Top.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Top.BorderColor3 = Color3.fromRGB(20, 20, 20)
Top.Size = UDim2.new(1, 0, 0, 20)

Spec.Name = "Spec"
Spec.Parent = Top
Spec.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Spec.BorderColor3 = Color3.fromRGB(20, 20, 20)
Spec.Size = UDim2.new(0.5, 0, 1, 0)
Spec.Font = Enum.Font.SourceSansLight
Spec.Text = "Spectator"
Spec.TextColor3 = Color3.new(1, 1, 1)
Spec.TextSize = 14

OBSM.Name = "OBSM"
OBSM.Parent = Top
OBSM.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
OBSM.BorderColor3 = Color3.fromRGB(20, 20, 20)
OBSM.Position = UDim2.new(0.5, 0, 0, 0)
OBSM.Size = UDim2.new(0.5, 0, 1, 0)
OBSM.Font = Enum.Font.SourceSansLight
OBSM.Text = "Point of View"
OBSM.TextColor3 = Color3.new(1, 1, 1)
OBSM.TextSize = 14

local Skin = {}
local straps = {}
local wraps = {}
local sports = {}
local fingerless = {}
for i,v in pairs(game.ReplicatedStorage.Skins:GetChildren()) do
	for a,b in pairs(v:GetChildren()) do
		table.insert(Skin, {v.Name.. "_".. b.Name})
	end
end
for i,v in pairs(game.ReplicatedStorage.Gloves:GetChildren()) do 
	if v.Name == "Wraps" or v.Name == "Guts" or v.Name == "MMA" or v.Name == "Wetland" or v.Name == "Ghoul Hex" or v.Name == "Phantom Hex" or v.Name == "Spector Hex" or v.Name == "Orange Hex" or v.Name == "Purple Hex" or v.Name == "Green Hex" then 
		table.insert(wraps,{v.Name})
	end
end
for i,v in pairs(game.ReplicatedStorage.Gloves:GetChildren()) do 
	if v.Name == "Scapter" or v.Name == "Patch" or v.Name == "Digital" or v.Name == "Crystal" then
		table.insert(fingerless,{v.Name})
	end
end
for i,v in pairs(game.ReplicatedStorage.Gloves:GetChildren()) do 
	if v.Name == "Hazard" or v.Name == "Hallows" or v.Name == "Majesty" or v.Name == "Royal" or v.Name == "Weeb" or v.Name == "CottonTail" or v.Name == "RSL" then 
		table.insert(sports,{v.Name})
	end
end
for i,v in pairs(game.ReplicatedStorage.Gloves:GetChildren()) do 
	if v.Name == "Grim" or v.Name == "Wisk" or v.Name == "Molten" or v.Name == "Kringle" or v.Name == "Racer" then 
		table.insert(straps,{v.Name})
	end
end
for i = 1,#straps do 
	table.insert(Skin,{"Strapped Glove_"..unpack(straps[i])})
end
for i = 1,#sports do 
	table.insert(Skin,{"Sports Glove_"..unpack(sports[i])})
end
for i = 1,#fingerless do 
	table.insert(Skin,{"Fingerless Glove_"..unpack(fingerless[i])})
end
for i = 1,#wraps do 
	table.insert(Skin,{"Handwraps_"..unpack(wraps[i])})
end
table.insert(Skin,{"CTKnife_Stock"})
table.insert(Skin,{"TKnife_Stock"})
for i,v in pairs(game.ReplicatedStorage.Skins:GetChildren()) do
	if v.Name ~= "Flip Knife" and v.Name ~= "Bayonet" and v.Name ~= "Falchion Knife" and v.Name ~= "Karambit" and v.Name ~= "Huntsman Knife" and v.Name ~= "Banana" and v.Name ~= "Butterfly Knife" then
		table.insert(Skin, {v.Name.. "_Stock"})
	end
end

function setLetters(text)
	if #text > 59 then return end
	for i,v in pairs(letters) do
		v.TextTransparency = 1
	end
	for i = 1, #text do
	    local c = text:sub(i,i)
	    letters[i].Text = c
		letters[i].TextTransparency = 0
	end
end

function CalculateAntiAngles(opposite)
	local Target
	if Settings.AA.Direction == "Nearest" then
		Target = AimbotFunctions.GetNearest()
	elseif Settings.AA.Direction == "All Threats" then
		for i,v in pairs(Services.Players:GetPlayers()) do
			Target = CalculateThreat(v)
			if Target then 
				break
			end
		end
	end

	if not Target then
		return
	end

	if Target and Target.Character and Target.Character:FindFirstChild("Head") and Target.Character:FindFirstChild("HumanoidRootPart") and isAlive(Local.Player) and Local.Player.Character and Local.Player.Character:FindFirstChild("Head") and Local.Player.Character:FindFirstChild("HumanoidRootPart") and Target.Character:FindFirstChild("HumanoidRootPart") then
		local OHRP = Target.Character.HumanoidRootPart
		local HRP = Local.Player.Character.HumanoidRootPart
		local vector1 = HRP.CFrame.p
		local vector2 = (OHRP.CFrame.p * Vector3.new(1,0,1)) + Vector3.new(0,vector1.Y,0)
		local lookAt = CFrame.new(vector1, vector2)
		local x, y, z = OHRP.CFrame:ToEulerAnglesYXZ()
		local lx, ly, lz = lookAt:ToEulerAnglesYXZ()
		local offset = opposite and math.pi or 0

		return lookAt * CFrame.Angles(0, y + ly + offset, 0)
	end
end

function Beam(v1, v2)
	local b1 = Instance.new("Part", workspace["Ray_Ignore"])
	b1.Size = Vector3.new(0.0001,0.0001,0.0001)
	b1.Transparency = 1
	b1.CanCollide = false
	b1.CFrame = CFrame.new(v1)
	b1.Anchored = true
	local a1 = Instance.new("Attachment", b1)
	local b2 = Instance.new("Part", workspace["Ray_Ignore"])
	b2.Size = Vector3.new(0.0001,0.0001,0.0001)
	b2.Transparency = 1
	b2.CanCollide = false
	b2.CFrame = CFrame.new(v2)
	b2.Anchored = true
	local a2 = Instance.new("Attachment", b2)
	local b = Instance.new("Beam", b1)
	b.FaceCamera = true
	b.Attachment0 = a1
	b.Attachment1 = a2
	b.LightEmission = 1
	b.LightInfluence = 0
	b.Color = ColorSequence.new(Settings.BulletTracerColor)
	b.Width0 = Settings.TracerThickness1 * 0.01
	b.Width1 = Settings.TracerThickness2 * 0.01
	b.Transparency = NumberSequence.new(Settings.BulletTracerTransparency)
	delay(0.25, function()
		for i = Settings.BulletTracerTransparency,1,0.02 do
			wait()
			b.Transparency = NumberSequence.new(i)
		end
		b1:Destroy()
		b2:Destroy()
	end)
end

--Silent


--[[
function preventfunctionduringsimulation(name)
	bruh = Local.Game[name]
	Local.Game[name] = function(...)
		if getfenv().callback then
			return
		end
		return bruh(...)
	end
end

preventfunctionduringsimulation("createparticle")
preventfunctionduringsimulation("createbullethole")
]]
--[[
local t = Local.Player.SkinFolder.TFolder:Clone()
local ct = Local.Player.SkinFolder.CTFolder:Clone()
t.Parent = Local.Player.SkinFolder
ct.Parent = Local.Player.SkinFolder
wait(1)
Local.Player.SkinFolder.TFolder:Destroy()
Local.Player.SkinFolder.CTFolder:Destroy()
]]

--hooks
spawn(function()
	repeat wait() until Local.Game.gui
	repeat wait() until Local.Game.JoinTeam

	local JoinTeam = Local.Game.JoinTeam
	Local.Game.JoinTeam = function()end

	Local.Game.gui.TeamSelection.Grn.MouseButton1Down:connect(function()
		script.Parent.Sounds.MenuClick:Play()
		JoinTeam("CT")
	end)
	Local.Game.gui.TeamSelection.Rd.MouseButton1Down:connect(function()
		script.Parent.Sounds.MenuClick:Play()
		JoinTeam("T")
	end)
end)

local Real;local Gun;local Team

meta = getrawmetatable(game)
if setreadonly then setreadonly(meta, false) else make_writeable(meta, true) end

local myClient = Local.PlayerGui.Client

newindexed = meta.__newindex
meta.__newindex = newclose(function(self, key, value)
	local Settings = Settings
	local callerScript = rawget(getfenv(0), "script")
	callerScript = typeof(callerScript) == "Instance" and callerScript or nil

	if self and type(value) == "string" and Settings.HideName then
		value = value:gsub(Local.Player.Name, Settings.Name)
	end

	if self and typeof(self) == "Instance" and self.Name == "player" and key == "Text" then
		if not Services.Players[value]:FindFirstChild("KarmaDone") then
			newindexed(self, "TextColor3", Color3.new(0,1,0))
		end
	end

	if Settings.Fakeduck and self and typeof(self) == "Instance" and self:IsA("Humanoid") and key == "CameraOffset" then
		value = Vector3.new(0, 0.05, 0)
	end
	
	--[[
	if callerScript == myClient and Local.Game.gun ~= "none" and self == Local.Camera and (key == "CFrame" or key == "CoordinateFrame") then
		local adder = value * Local.Camera.CFrame:inverse()
		local multiplier = Storage[Local.Game.gun.Name]

		local x, y, z = Local.Game.newangle:ToEulerAnglesYXZ()
		local newnewangle = CFrame.Angles(x*multiplier, y*multiplier, z*multiplier)
		if adder == Local.Game.newangle:inverse() then
			Local.Camera.CFrame = Local.Camera.CFrame * newnewangle:inverse()
		else
			Local.Camera.CFrame = Local.Camera.CFrame * newnewangle
		end
		return
	end]]

	return newindexed(self, key, value)
end)
tempgun = nil
indexed = meta.__index
meta.__index = newclose(function(self, key)
	local callerScript = rawget(getfenv(0), "script")
	callerScript = typeof(callerScript) == "Instance" and callerScript or nil
	local scriptName = indexed(callerScript, "Name")

	if scriptName == "DisplayChat" and indexed(self, "Name") == "RoundOver" and key == "Value" and Settings.AllChat then
		return true
	end

	return indexed(self, key)
end)
hitpartdebounce = true
filterdebounce = true
namecall = meta.__namecall
meta.__namecall = newclose(function(self, ...)
	local method = getnamecallmethod()
	local args = {...}
	local Settings = Settings
    local Player = Local.Player
    
    if method == "FindPartOnRayWithIgnoreList" and fakeCFrame and args[2][7] and args[2][7].Name == "HumanoidRootPart" then
        local Goal = fakeCFrame
        local Start = AimbotFunctions.getRealCameraVector(Player.Character)
        print("Reassing")
        args[1] = Ray.new(Start, (Goal - Start).unit * 500)
        print("BOO!")
    end

	if method == "FireServer" and self.Name == "HitPart" and hitpartdebounce then
		local stat = Storage.Target[2]
		if Settings[stat].HookHitpart then
			local ourCFrame = AimbotFunctions.getRealCameraVector(Player.Character)
			local hit, hitpos, dm, wb = AimbotFunctions.SimulateShot(CFrame.new(ourCFrame, Storage.Target[1][1]), Target[3].Character)
			if hit then
				args[1] = Storage.Target[1][2]
				args[2] = Storage.Target[1][1]
				args[8] = 1
			end
		end
		if Settings[stat].OverrideDamage then
			args[8] = Settings[stat].Damage
		end
		if bodyParts[args[1].Name] then
			lastHit = {args[1], args[10], args[8] * Local.Game.gun.DMG.Value}
		end
		if args[1].Parent.Parent == Backtrack then
			local myPart = args[1].PT.Value
			if myPart then
				args[1] = myPart
				args[2] = myPart.Position
			end
		end
		hitpartdebounce = false
		Events.HitPart:FireServer(unpack(args))
		hitpartdebounce = true
		return
	end
	if method == "FindPartOnRayWithWhitelist" and #args[2] == 1 and args[2][1].Name == "SpawnPoints" and Settings.Buymenu then
		local Team = Player.Status.Team.Value
		local SpawnPoints = workspace.Map.SpawnPoints
		workspace.Status.BuyTime.Value = 5
		if Team == "T" then
			return SpawnPoints.BuyArea
		elseif Team == "CT" then
			return SpawnPoints.BuyArea2
		end
	end
	if method == "GetState" then
		return Enum.HumanoidStateType.Physics
	end
	if method == "SetPrimaryPartCFrame" and self.Name == "Arms2" then
		args[1] = args[1] * CFrame.new(Settings.VX - 2.5, Settings.VY - 2.5, Settings.VZ - 2.5)
	end
	if method == "FireServer" and self.Name == "ThrowGrenade" and Settings.InfNades then
		namecall(self, unpack(args))
		error("Spoofed Grenade.")
	end
	if method == "FireServer" and self.Name == "ControlTurn" and Player.Character then 
		--local hrp = Player.Character:FindFirstChild("HumanoidRootPart")
		if Settings.AA.Enabled then
			return namecall(self, Settings.AA.Pitch - 1)
		end
	end
	if method == "CaptureFocus" then
		if UI.pointer.Visible then
			return
		end
	end
	if method == "FireServer" and self.Name == "PlantC4" and Settings.Antidefuse then
		args[1] = Player.Character.HumanoidRootPart.CFrame + Vector3.new(0,-10,0)
		args[2] = ""
	end
	if method == "FireServer" and self.Name == "PlayerChatted" and Settings.ChatAlive then 
		args[4] = false
	end
	if method == "FireServer" and self.Name == "BURNME" and Settings.AntiMolotov then 
		return 
	end
	if method == "FireServer" and self.Name == "FallDamage" and Settings.NoFall then 
		return 
	end
	if method == "FireServer" and self.Name == "ReplicateCamera" then 
		succ = pcall(function()
			args[1] = Local.Player.Character.Head.CFrame
		end)
	end
	if method == "InvokeServer" and self.Name == "Hugh" then 
		return
	end 
	if method == "FireServer" and args[1] == Player.UserId then 
		return
	end 
	if method == "FireServer" and string.len(self.Name) == 38 then
		return nil
	end
	if method == "FireServer" and self.Name == "DataEvent" and Settings.SkinChanger then
		for i,v in next, args do 
			Team = v[2]
			Gun = v[3]
			table.foreach(v[4],function(k,v)
			Real = v
			end)
			local ctfolder = Player.SkinFolder.CTFolder
			local tfolder = Player.SkinFolder.TFolder
			if Team == "CT" or Team == "Both" then 
				for a,b in pairs(ctfolder:GetChildren()) do
					if Gun == "Gut Knife" or Gun == "Butterfly Knife" or Gun == "Falchion Knife" or Gun == "Bayonet" or Gun == "Huntsman Knife" or Gun == "Karambit" or Gun == "Banana" or Gun == "Flip Knife" or Gun == "Bearded Axe" or Gun == "Sickle" or Gun == "Cleaver" and b.Name == "Knife" then
						local getskin = string.split(Real,"_")
						b.Value = tostring(getskin[2])
					elseif b.Name == Gun then
						local getskin = string.split(Real,"_")
						b.Value = tostring(getskin[2])
					end
				end
			end
			if Team == "T" or Team == "Both" then 
				for c,d in pairs(tfolder:GetChildren()) do
					if Gun == "Gut Knife" or Gun == "Butterfly Knife" or Gun == "Falchion Knife" or Gun == "Bayonet" or Gun == "Huntsman Knife" or Gun == "Karambit" or Gun == "Banana" or Gun == "Flip Knife" or Gun == "Bearded Axe" or Gun == "Sickle" or Gun == "Cleaver" and d.Name == "Knife" then
						local getskin = string.split(Real,"_")
						d.Value = tostring(getskin[2])
					elseif d.Name == Gun then
						local getskin = string.split(Real,"_")
						d.Value = tostring(getskin[2])
					end
				end
			end
		end
	end
	return namecall(self, unpack(args))
end)

if setreadonly then setreadonly(meta, true) else make_writeable(meta, false) end

Events.SendMsg.OnClientEvent:connect(function(p22, p23)
	print(p22)
end)

Events.PlayerChatted.OnClientEvent:connect(function(p9, p10, p11, p12, p13, p14, p15)
	wait(0.6)
	if Settings.Unhash then
		p11 = game.ReplicatedStorage.Functions.Filter:InvokeServer(p10, game.Players:FindFirstChild(p9));
		if p11:find("#") then
			local player = Services.Players:FindFirstChild(p9)
			local playerColor = BrickColor.new("White");
			if player and player.Status.Team.Value == "T" then
				local playerColor = BrickColor.new("Bright yellow");
			elseif player and player.Status.Team.Value == "CT" then
				playerColor = BrickColor.new("Bright blue");
			end

			Local.Chat.moveOldMessages()

			local Tag = Instance.new("TextLabel", Local.PlayerGui.GUI.Main.Chats);
			Tag.Name = "Line1";
			Tag.BackgroundTransparency = 1;
			Tag.BorderSizePixel = 0;
			Tag.Size = UDim2.new(0, 590, 0, 30);
			Tag.Position = UDim2.new(0.01, 0, 0, 147);
			Tag.TextColor3 = Color3.new(0,1,0);
			Tag.TextStrokeColor3 = Color3.new(0, 0, 0);
			Tag.TextStrokeTransparency = Tag.TextTransparency;
			Tag.TextWrapped = false;
			Tag.Font = "ArialBold";
			Tag.FontSize = "Size14";
			Tag.TextXAlignment = "Left";
			Tag.Text = "(UNHASHED)";
			Tag.Size = UDim2.new(0, Tag.TextBounds.X, 0, 30);
			Local.Chat.createNewMessage(player.Name, p10, playerColor.Color, Color3.new(255, 255, 255), 0.2, v31);
		end
	end
end)

local hitobject = Local.Game.hitobject

Local.Game.hitobject = function(Hit, Pos, normal, gunstats, stabbing)
	if Settings.BulletTracers then
		local ourCFrame = AimbotFunctions.getRealCameraVector(Local.Player.Character)
		Beam(ourCFrame, Pos)
	end
	lastPoint = Pos
	hitobject(Hit, Pos, normal, gunstats, stabbing)
end

fire = Local.Game.firebullet

Local.Game.firebullet = function(fanfire)
	if Settings.HookHitpart then
		return fire(fanfire)
	end
	if not Storage.Target then
		print("No target.")
		return fire(fanfire)
	end	
	local stat = Storage.Target[2]
	if (Settings[stat].AimbotMode == "Enabled" or (Settings[stat].AimbotMode == "On Key" and Services.UserInputService:IsKeyDown(Storage[stat.."Aimkey"].key))) then
		local CFrameStorage = Local.Camera.CFrame
		fakeCFrame = Storage.Target[1][1]
		if Settings[stat].AimbotStyle == "Flick when shooting" then
			print("breh")
			Local.Camera.CFrame = CFrame.new(Local.Camera.CFrame.p, Storage.Target[1][1])
		end
		fire(fanfire)
		fakeCFrame = nil
		if Settings[stat].AimbotStyle == "Flick when shooting" then
			wait()
			Local.Camera.CFrame = CFrameStorage
		end
	else
		fire(fanfire)
	end
end

--bruh

function LocalFOV(number) 
	Local.Game.fieldofview = number
  	Local.Camera.FieldOfView = number
end

debounce = false

function TriggerRoutine()
	debounce = true
  	if Local.Mouse.Target and isAlive(Local.Player) and (Settings.TriggerbotMode == "Enabled" or (Settings.TriggerbotMode == "On Key" and Services.UserInputService:IsKeyDown(Triggerkey.key))) then
		local OtherHuman = Local.Mouse.Target.Parent
		if OtherHuman.Parent == Backtrack then
			if Settings.TriggerbotDelay ~= 0 then
				wait(Settings.TriggerbotDelay)
			end
			if not debounce then
				mouse1press()
				wait(0.04)
				mouse1release()
			end
			debounce = false
			return
		end
		local OtherPlayer = Services.Players:FindFirstChild(OtherHuman.Name)
		if not OtherPlayer then 
			debounce = false
			return 
		end
		if OtherPlayer.Team == Local.Player.Team then 
			debounce = false
			return 
		end
		if Settings.TriggerbotDelay ~= 0 then
			wait(Settings.TriggerbotDelay)
		end
		if not debounce then
			mouse1press()
			wait(0.04)
			mouse1release()
		end
	end
	debounce = false
end

local DefaultBot = "Legit"
local Defaults = {}
local Core = UI:CreateWindow("Qual")

local bruh = Instance.new("Frame")
local UIListLayoutaa = Instance.new("UIListLayout")

bruh.Parent = UI.base
bruh.ZIndex = 25
bruh.BackgroundColor3 = Color3.new(1, 1, 1)
--bruh.Size = UDim2.new(0,0,0,0)
bruh.Visible = false

UIListLayoutaa.Parent = bruh
UIListLayoutaa.SortOrder = Enum.SortOrder.LayoutOrder

function CalculateThreat(p)
	local ignorelist = {Local.Camera, Local.Player.Character, part, p.Character, Backtrack}
	local parts = Local.Camera:GetPartsObscuringTarget({p.CameraCF.Value.p}, ignorelist)
	if #parts < 2 then
		return true
	end
end

ESPLocation = Instance.new("Folder", Services.CoreGui)

function espPart(part,v)
	local inneresp = Instance.new("BoxHandleAdornment",ESPLocation)
	inneresp.Adornee = part
	if (Settings.InnerChams.Allies.VisibleOnly and v.Team == Local.Player.Team) or (Settings.InnerChams.Enemies.VisibleOnly and v.Team ~= Local.Player.Team) then  
		inneresp.AlwaysOnTop = false
	else
		inneresp.AlwaysOnTop = true
	end
	inneresp.ZIndex = 2
	if (Settings.InnerChams.Allies.Render and v.Team == Local.Player.Team) or (Settings.InnerChams.Enemies.Render and v.Team ~= Local.Player.Team) then
		inneresp.Transparency = (v.Team == Local.Player.Team and Settings.InnerChams.Allies.Transparency) or Settings.InnerChams.Enemies.Transparency
	else
		inneresp.Transparency = 1
	end
	inneresp.Size = part.Size + Vector3.new(0.01,0.01,0.01)
	if v.Team == Local.Player.Team then
		inneresp.Color3 = (Settings.InnerChams.Allies.UseTeamColor and v.TeamColor.Color) or Settings.InnerChams.Allies.Color                               
	else
		inneresp.Color3 = (Settings.InnerChams.Enemies.UseTeamColor and v.TeamColor.Color) or Settings.InnerChams.Enemies.Color
	end
		
	v.CharacterRemoving:Connect(function()
		inneresp:Destroy()
	end)

	local outeresp = Instance.new("BoxHandleAdornment",ESPLocation)
	outeresp.Adornee = part
	if (Settings.OuterChams.Allies.VisibleOnly and v.Team == Local.Player.Team) or (Settings.OuterChams.Enemies.VisibleOnly and v.Team ~= Local.Player.Team) then  
		outeresp.AlwaysOnTop = false
	else
		outeresp.AlwaysOnTop = true
	end
	outeresp.ZIndex = 1
	if (Settings.OuterChams.Allies.Render and v.Team == Local.Player.Team) or (Settings.OuterChams.Enemies.Render and v.Team ~= Local.Player.Team) then
		outeresp.Transparency = (v.Team == Local.Player.Team and Settings.OuterChams.Allies.Transparency) or Settings.OuterChams.Enemies.Transparency
	else
		outeresp.Transparency = 1
	end
	local Size = (v.Team == Local.Player.Team and Settings.OuterChams.Allies.Size) or Settings.OuterChams.Enemies.Size
	outeresp.Size = part.Size + Vector3.new(Size,Size,Size)
	if v.Team == Local.Player.Team then
		outeresp.Color3 = (Settings.OuterChams.Allies.UseTeamColor and v.TeamColor.Color) or Settings.OuterChams.Allies.Color                               
	else
		outeresp.Color3 = (Settings.OuterChams.Enemies.UseTeamColor and v.TeamColor.Color) or Settings.OuterChams.Enemies.Color
	end
		
	v.CharacterRemoving:Connect(function()
		outeresp:Destroy()
	end)
end
 
function espPlayer(v)
    if isAlive(v) then
        for _,part in pairs(v.Character:GetChildren())do
            if part:IsA("BasePart") then
                espPart(part,v)
            end
		end
		if (Settings.Allies.Healthbar.Enabled and v.Team == Local.Player.Team) or (Settings.Enemies.Healthbar.Enabled and v.Team ~= Local.Player.Team) then
			local Healthbar = Instance.new("BillboardGui")
			local Out = Instance.new("Frame")
			local Inside = Instance.new("Frame")

			Healthbar.Parent = ESPLocation
			Healthbar.Active = true
			Healthbar.Adornee = v.Character:FindFirstChild("LowerTorso")
			Healthbar.AlwaysOnTop = true
			Healthbar.Size = UDim2.new(6, 0, 5.5, 0)
			Healthbar.StudsOffsetWorldSpace = Vector3.new(0, 0.2, 0)

			Out.Parent = Healthbar
			Out.BackgroundColor3 = Color3.new(0.25, 0.25, 0.25)
			Out.BorderSizePixel = 0
			Out.LayoutOrder = 100
			Out.Size = UDim2.new(0.04, 0, 1, 0)

			Inside.Parent = Healthbar
			Inside.BackgroundColor3 = (v.Team == Local.Player.Team and Settings.Allies.Healthbar.Color) or Settings.Enemies.Healthbar.Enabled
			Inside.BorderSizePixel = 0
			Inside.LayoutOrder = 100
			Inside.Size = UDim2.new(0.04, 0, 1, 0)
			Inside.ZIndex = 2

			local hm = v.Character.Humanoid
			hm:GetPropertyChangedSignal("Health"):Connect(function()
				Inside.Position = UDim2.new(0, 0, 1-(hm.Health/100), 0)
				Inside.Size = UDim2.new(0.04, 0, hm.Health/100, 0)
		  	end)
		end
    end
end
 
function ESP()
    ESPLocation:ClearAllChildren()
    for _,v in pairs(Services.Players:GetPlayers())do
		if v.Name ~= Local.Player.Name then
			pcall(function()
				espPlayer(v)
			end)
        end
    end
end
 
spawn(function()
    while wait(4) do
        ESP()
    end
end)

function lerp(v0, v1, t) 
	return (1 - t) * v0 + t * v1
end

function CalculateAimbot()
	local Nearest
	if Settings[DefaultBot].DetectionMethod == "All Threats (360°)" then
		Nearest = Storage.Targets[1]
	else
		Nearest = AimbotFunctions.GetClosestToCrosshair()
		if not Nearest and Settings[DefaultBot].DetectionMethod == "Crosshair or Nearest (360°)" then
			Nearest = AimbotFunctions.GetNearest()
		end
	end

	if not Nearest then return end
	if not isAlive(Nearest) then return end

	Storage.Targets = {}

	local stat = getStatus(Nearest)
	if stat == "Friend" then return end

	local Aimpoint
	local allCorners = {}

	if stat == "Rage" then
		for i,v in pairs(AimbotFunctions.getAimpoints(Nearest.Character)) do
			if not Aimpoint then
				local ourCFrame = AimbotFunctions.getRealCameraVector(Local.Player.Character)
				local hit, hitpos = AimbotFunctions.SimulateShot(CFrame.new(ourCFrame, v), Nearest.Character)
				if hit then
					Aimpoint = {hitpos, v}
				end
			end
		end
		if not Aimpoint then
			for _,v in pairs(Nearest.Character:GetChildren()) do
				if v:isA("BasePart") and ToSimplified[v.Name] then
					local a = AimbotFunctions.getAimCorners(v.CFrame, v.Size)
					for _,corner in pairs(a) do
						if AimbotFunctions.VectorVisible(corner, Nearest) then
							table.insert(allCorners, {corner, v})
						end
					end
				end
			end
			table.sort(allCorners, function(a, b)
				return HitboxPriorities[ToSimplified[a[2].Name]] > HitboxPriorities[ToSimplified[b[2].Name]]
			end)
			if #allCorners == 0 then
				return false
			end
			Aimpoint = allCorners[1]
		end
	else
		local body = "Head"
		if Settings.Legit.Headshotchance < math.random(1, 100) then
			body = "LowerTorso"
		end
		if not Nearest.Character:FindFirstChild(body) then return end
		Aimpoint = {Nearest.Character[body].Position, Nearest.Character[body]}
	end

	return {Aimpoint, stat, Nearest}
end

function canFire()
	local Game = Local.Game
	return 0 < Game.ammocount4 and Game.equipped == "equipment2" or 0 < Game.ammocount3 and Local.Game.equipped == "equipment" or 0 < Local.Game.ammocount and Local.Game.equipped == "primary" or 0 < Local.Game.ammocount2 and Local.Game.equipped == "secondary" or Local.Game.gun ~= "none" and Local.Game.gun and Local.Game.gun ~= "none" and Local.Game.gun:FindFirstChild("Melee")
end

function Chat(Message)
	Events.PlayerChatted:FireServer(Message, false, "Innocent", false, false)
end

local indexOf = function( t, object )
    if "table" == type( t ) then
        for i = 1, #t do
            if object == t[i] then
                return i
            end
        end
        return -1
    else
        error("table.indexOf expects table for first argument, " .. type(t) .. " given")
    end
end



local default_debounce = false
for tab,prefix in pairs({"Legit", "Rage"}) do
	bottab = Core:CreateTab(prefix.."bot")
	SAim = bottab:AddLocalTab(prefix.." Silent Aim")

	local df = SAim:AddToggle("Default", Settings.DefaultBot == prefix, function(b)
		if b and default_debounce then
			default_debounce = false
			for i,v in pairs(Defaults) do
				if prefix ~= i then
					v:SetToggle(false)
				end
			end
			default_debounce = true
			Settings.DefaultBot = prefix
		end
		if not b and default_debounce then
			default_debounce = false
			Defaults[prefix]:SetToggle(true)
			default_debounce = true
		end
	end)

	Defaults[prefix] = df
	
	local AMode = {"Enabled", "On Key", "Disabled"}
	SAim:AddDropdown("Mode", indexOf(AMode, Settings[prefix].AimbotMode), AMode, function(m)
		Settings[prefix].AimbotMode = m
	end)
	
	local AMethod = {"Closest to Crosshair", "Crosshair or Nearest (360°)", "All Threats (360°)"}
	SAim:AddDropdown("Method", indexOf(AMethod, Settings[prefix].DetectionMethod), AMethod, function(m)
		Settings[prefix].DetectionMethod = m
	end)

	local StMode = {"Completely Silent", "Flick when shooting", "Track target"}
	SAim:AddDropdown("Mode", indexOf(StMode, Settings[prefix].AimbotStyle), StMode, function(m)
		Settings[prefix].AimbotStyle = m
	end)

	SAim:AddSlider("FOV in pixels", 200, Settings[prefix].FOVpx, function(n)
		Settings[prefix].FOVpx = n
		Storage[prefix.."Circle"].Radius = n
	end)

	SAim:AddToggle("Remove FOV limit", Settings[prefix].FOVlim, function(b)
		Settings[prefix].FOVlim = b
	end)

	if prefix == "Legit" then
		SAim:AddSlider("Headshot chance", 100, Settings[prefix].Headshotchance, function(n)
			Settings[prefix].Headshotchance = n
		end)
	end

	Storage[prefix.."Aimkey"] = SAim:AddKeybind("Aimkey", Enum.KeyCode[Settings[prefix].Aimkey])

	backtracktab = bottab:AddLocalTab("Backtrack")

	backtracktab:AddToggle("Backtrack", Settings[prefix].Backtrack, function(b)
		Settings[prefix].Backtrack = b
	end)

	backtracktab:AddSlider("Backtrack Length", 2000, Settings[prefix].BacktrackDelay, function(n)
		Settings[prefix].BacktrackDelay = n
	end)

	backtracktab:AddCP("Backtrack Color", Settings[prefix].BacktrackColor, function(c3, alpha)
		Settings[prefix].BacktrackColor = c3
		if alpha then
			Settings[prefix].BacktrackTransparency = alpha
		end
	end, Settings[prefix].BacktrackTransparency)

	backtracktab:AddToggle("Backtrack Rainbow", Settings[prefix].BacktrackRainbow, function(b)
		Settings[prefix].BacktrackRainbow = b
	end)

	if prefix == "Legit" then
		local TB = bottab:AddLocalTab("Triggerbot")
		TMode = {"Enabled", "On Key", "Disabled"}
		TB:AddDropdown("Mode", indexOf(TMode, Settings.TriggerbotMode), TMode, function(m)
			Settings.TriggerbotMode = m
			if Storage.Triggerbot then
				Storage.Triggerbot:disconnect()
			end
			if m == "Enabled" or m == "On Key" then
				Storage.Triggerbot = S:connect(TriggerRoutine)
			end
		end)
		
		TB:AddSlider("Delay", 100, Settings.TriggerbotDelay, function(d)
			Settings.TriggerbotDelay = d
		end)

		Triggerkey = TB:AddKeybind("Triggerbot key", Enum.KeyCode[Settings.Triggerkey])
	end

	ASTab = bottab:AddLocalTab("Auto-shoot")

	ASTab:AddToggle("Auto-shoot", Settings[prefix].Shootbot, function(b)
		Settings[prefix].Shootbot = b
	end)

	ASTab:AddToggle("Autowall", Settings[prefix].Autowall, function(b)
		Settings[prefix].Autowall = b
	end)

	ASTab:AddSlider("Minimum Damage (Visible)", 100, Settings[prefix].MinVisibleDamage, function(d)
		Settings[prefix].MinVisibleDamage = d
	end)

	ASTab:AddSlider("Minimum Damage (Autowall)", 100, Settings[prefix].MinAWDamage, function(d)
		Settings[prefix].MinAWDamage = d
	end)

	DBTab = bottab:AddLocalTab("Damage Boosting")

	DBTab:AddToggle("Hook Hitpart", Settings[prefix].HookHitpart, function(b)
		Settings[prefix].HookHitpart = b
	end)

	DBTab:AddToggle("Override Damage", Settings[prefix].OverrideDamage, function(b)
		Settings[prefix].OverrideDamage = b
	end)

	DBTab:AddSlider("Damage Multiplier", 2, Settings[prefix].Damage, function(d)
		Settings[prefix].Damage = d
	end, 0.01)
end

default_debounce = true

local Visuals = Core:CreateTab("Visuals")
local BTtab = Visuals:AddLocalTab("Bullet Tracers")
local FV = Visuals:AddLocalTab("FOV Circle")

for i,BAWT in pairs({"Legit", "Rage"}) do
	FV:AddToggle(BAWT.." Circle Enabled", Settings[BAWT].FOVCircle, function(b)
		Settings[BAWT].FOVCircle = b
		Storage[BAWT.."Circle"].Visible = b
	end)

	FV:AddToggle(BAWT.." Circle Filled", Settings[BAWT].FOVFilled, function(b)
		Settings[BAWT].FOVFilled = b
		Storage[BAWT.."Circle"].Filled = b
	end)

	FV:AddCP(BAWT.." Circle Color", Settings[BAWT].FOVColor, function(c3, alpha)
		Settings[BAWT].FOVColor = c3
		if alpha then
			Settings[BAWT].FOVTransparency = alpha
			Storage[BAWT.."Circle"].Transparency = 1-alpha
		end
		Storage[BAWT.."Circle"].Color = c3
	end, Settings[BAWT].FOVTransparency)

	FV:AddSlider(BAWT.." Circle Thickness", 5, Settings[BAWT].FOVThickness, function(v)
		Settings[BAWT].FOVThickness = v
		Storage[BAWT.."Circle"].Thickness = v
	end)
end

BTtab:AddToggle("Enabled", Settings.BulletTracers, function(b)
	Settings.BulletTracers = b
end)

BTtab:AddSlider("Starting Thickness", 10, Settings.TracerThickness1, function(v)
	Settings.TracerThickness1 = v
end)

BTtab:AddSlider("Ending Thickness", 10, Settings.TracerThickness2, function(v)
	Settings.TracerThickness2 = v
end)

BTtab:AddCP("Color", Settings.BulletTracerColor, function(c3, alpha)
	Settings.BulletTracerColor = c3
	if alpha then
		Settings.BulletTracerTransparency = alpha
	end
end, Settings.BulletTracerTransparency)

for i,v in pairs({"Arms", "Gun"}) do
	local lTab = Visuals:AddLocalTab(v)

	lTab:AddToggle("Enabled", Settings[v.."Enabled"], function(b)
		Settings[v.."Enabled"] = b
		doSelfChams()
	end)
	
	lTab:AddDropdown("Material", indexOf(Materials, Settings[v.."Material"]), Materials, function(d)
		Settings[v.."Material"] = d
		doSelfChams()
	end)
	
	lTab:AddCP("Color", Color3.new(1, 0.5, 0), function(c3, alpha)
		Settings[v.."Color"] = c3
		if alpha then
			Settings[v.."Transparency"] = alpha
		end
		doSelfChams()
	end, 0.3)
end

local Viewmodel = Visuals:AddLocalTab("Viewmodel")

Viewmodel:AddToggle("Remove Sleeves", Settings.NoSleeves, function(b)
	Settings.NoSleeves = b
	doSelfChams()
end)

Viewmodel:AddToggle("Remove Gloves", Settings.NoGloves, function(b)
	Settings.NoGloves = b
	doSelfChams()
end)


--[[
local ViewmodelOffset = Visuals:AddLocalTab("Viewmodel Offsets")

for i,v in pairs({"X", "Y", "Z"}) do
	ViewmodelOffset:AddSlider(v.." Offset", 5, Settings["V"..v], function(v)
		Settings["V"..v] = v
	end)
end
]]

function getpartmodifier(part)
	local partmodifier = 0
	if part.Material == Enum.Material.DiamondPlate then
		partmodifier = 3
	end
	if part.Material == Enum.Material.CorrodedMetal or part.Material == Enum.Material.Metal or part.Material == Enum.Material.Concrete or part.Material == Enum.Material.Brick then
		partmodifier = 2
	end
	if part.Name == "Grate" or part.Material == Enum.Material.Wood or part.Material == Enum.Material.WoodPlanks or part and part.Parent and part.Parent:FindFirstChild("Humanoid") then
		partmodifier = 0.1
	end
	if part.Transparency == 1 or part.CanCollide == false or part.Name == "Glass" or part.Name == "Cardboard" or part:IsDescendantOf(workspace.Ray_Ignore) or part:IsDescendantOf(workspace.Debris) or part and part.Parent and part.Parent.Name == "Hitboxes" then
		partmodifier = 0
	end
	if part.Name == "nowallbang" then
		partmodifier = 90
	end
	if part:FindFirstChild("PartModifier") then
		partmodifier = part.PartModifier.Value
	end
	return partmodifier
end

transparencies = {}

function EnableAsus(p)
	if not transparencies[p] then
		transparencies[p] = p.Transparency
	end
	p.Transparency = Settings.AsusWalls.Transparency
	return
end

function Asus(p)
	if not p:IsA("BasePart") then return end
	if Settings.AsusWalls.Enabled then
		if Settings.AsusWalls.IncludeUnwallbangable then
			return EnableAsus(p)
		end
		if getpartmodifier(p) < Settings.AsusWalls.PartModifier then
			return EnableAsus(p)
		end
	end
	if transparencies[p] then
		p.Transparency = transparencies[p]
	end
end

asusdebounce = true

function AsusWorkspace()
	asusdebounce = false
	delay(5, function()
		for i,p in pairs(workspace.Map:GetDescendants()) do
			Asus(p)
		end
		asusdebounce = true
	end)
end

spawn(function()
	workspace:WaitForChild("Map").DescendantAdded:connect(function(p)
		Asus(p)
	end)
end)


local AsusWalls = Visuals:AddLocalTab("Asus Walls")

AsusWalls:AddToggle("Enabled", Settings.AsusWalls.Enabled, function(b)
	Settings.AsusWalls.Enabled = b
	if asusdebounce then
		AsusWorkspace()
	end
end)

AsusWalls:AddSlider("Transparency", 1, Settings.AsusWalls.Transparency, function(v)
	Settings.AsusWalls.Transparency = v
	if asusdebounce then
		AsusWorkspace()
	end
end, 0.01)

AsusWalls:AddSlider("Wallbangability Threshold", 5, Settings.AsusWalls.PartModifier, function(v)
	Settings.AsusWalls.PartModifier = v
	if asusdebounce then
		AsusWorkspace()
	end
end, 0.01)

AsusWalls:AddToggle("Include Unwallbangable", Settings.AsusWalls.IncludeUnwallbangable, function(b)
	Settings.AsusWalls.IncludeUnwallbangable = b
	if asusdebounce then
		AsusWorkspace()
	end
end)


--[[
for i,v in pairs({"X", "Y", "Z"}) do
	ViewmodelOffset:AddSlider(v.." Offset", 5, Settings["V"..v], function(v)
		Settings["V"..v] = v
	end)
end]]

local VisualMisc = Visuals:AddLocalTab("Misc")

VisualMisc:AddToggle("SpectatorUI", Settings.SpectatorUI, function(b)
	Settings.SpectatorUI = b
	SpecF.Visible = b
end)

VisualMisc:AddToggle("Watermark", Settings.Watermark, function(b)
	Settings.Watermark = b
	WBack.Visible = b
end)

VisualMisc:AddToggle("Better Scope", Settings.BetterScope, function(enabled)
	Settings.BetterScope = enabled
	if enabled then
		local ScopeStorageQuery = {}
		local Crosshairs = Local.PlayerGui.GUI.Crosshairs
		table.insert(ScopeStorage, Crosshairs.Scope)
		table.insert(ScopeStorage, Crosshairs.Frame1)
		table.insert(ScopeStorage, Crosshairs.Frame2)
		table.insert(ScopeStorage, Crosshairs.Frame3)
		table.insert(ScopeStorage, Crosshairs.Frame4)
		Crosshairs.Scope.Parent = Services.Lighting
		Crosshairs.Frame1.Parent = Services.Lighting
		Crosshairs.Frame2.Parent = Services.Lighting
		Crosshairs.Frame3.Parent = Services.Lighting
		Crosshairs.Frame4.Parent = Services.Lighting
		Scope.Parent = Crosshairs
		Frame1.Parent = Crosshairs
		Frame2.Parent = Crosshairs
		Frame3.Parent = Crosshairs
		Frame4.Parent = Crosshairs
		Local.Game.Scope = Scope
	else
		local Crosshairs = Local.PlayerGui.GUI.Crosshairs
		Scope.Parent = Services.Lighting
		Frame1.Parent = Services.Lighting
		Frame2.Parent = Services.Lighting
		Frame3.Parent = Services.Lighting
		Frame4.Parent = Services.Lighting
		for i,v in pairs(ScopeStorage) do
			if v.Name == "Scope" then
				Local.Game.Scope = v
			end
			v.Parent = Crosshairs
		end
	end
end)

local EV = Visuals:AddLocalTab("Environment")
local Camera = Visuals:AddLocalTab("Camera")


Camera:AddSlider("FOV", 120, Settings.FOV, LocalFOV)

thirdpersontoggle = false
Camera:AddKeybind("Thirdperson Toggle", Enum.KeyCode[Settings.ThirdpersonKey], function()
	thirdpersontoggle = not thirdpersontoggle
	if thirdpersontoggle then
		Local.Player.CameraMaxZoomDistance = Settings.ThirdpersonDistance
		Local.Player.CameraMinZoomDistance = Settings.ThirdpersonDistance
		wait()
		Local.Player.CameraMaxZoomDistance = Settings.ThirdpersonDistance
		Local.Player.CameraMinZoomDistance = Settings.ThirdpersonDistance
	else
		Local.Player.CameraMaxZoomDistance = 0.5
		Local.Player.CameraMinZoomDistance = 0.5
		wait() --no clue why but u need to do this twice
		Local.Player.CameraMaxZoomDistance = 0.5
		Local.Player.CameraMinZoomDistance = 0.5
	end
end, false)

Spectatorkey = Camera:AddKeybind("Spectator view key", Enum.KeyCode[Settings.Spectatorkey])

local Hit = Visuals:AddLocalTab("On hit")

Hit:AddToggle("Hitmarker", Settings.Hitmarker, function(b)
	Settings.Hitmarker = b
end)

Hit:AddToggle("Hitmarker follow hit", Settings.HitmarkerTarget, function(b)
	Settings.HitmarkerTarget = b
end)

Hit:AddToggle("Enable Hitsounds", Settings.HitsoundEnabled, function(b)
	Settings.HitsoundEnabled = b
end)

Hit:AddDropdown("Hitsound", indexOf(HitsoundsTable, Settings.Hitsound), HitsoundsTable, function(d)
	Settings.Hitsound = d
end)

function OnHit(name, damage)
	if Settings.HitsoundEnabled then
		PlaySound(Hitsounds[Settings.Hitsound])
	end

	local additive = ""
	if lastHit then
		additive = " at "..lastHit[1].Name
		if lastHit[2] then
			additive = additive.." through a wall"
		end
		additive = additive.." ("..lastHit[3]..")".." ("..lastHit[3] - damage..")"
	end
	
	local TextLabel = Instance.new("TextLabel")
	TextLabel.Parent = DaFrame
	TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Size = UDim2.new(0, 302, 0, 20)
	TextLabel.Font = Enum.Font.Code
	TextLabel.Text = "Hit "..name.." for "..damage..additive
	TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	TextLabel.TextSize = 14
	TextLabel.TextStrokeTransparency = 0
	TextLabel.TextXAlignment = Enum.TextXAlignment.Left

	delay(5, function()
		for i = 0,1,0.01 do
			wait()
			TextLabel.TextTransparency = i
			TextLabel.TextStrokeTransparency = i
		end
		TextLabel:Destroy()
	end)

  	if Settings.Hitmarker then --CurrentConfig().Hitmarker.Enabled
		local Line = Drawing.new("Line")
		local Line2 = Drawing.new("Line")
		local Line3 = Drawing.new("Line")
		local Line4 = Drawing.new("Line")

		local Color = Color3.new(1,1,1)--CurrentConfig().Hitmarker.Color()
		local x, y
		local pos = lastPoint
		if Settings.HitmarkerTarget then
			local vector, onScreen = Local.Camera:WorldToViewportPoint(pos)
			x, y = vector.X, vector.Y
		else
			local Size = Local.Camera.ViewportSize
			x, y = Size.X/2, Size.Y/2
		end
		
		Line.From = Vector2.new(x + 4, y + 4)
		Line.To = Vector2.new(x + 10, y + 10)
		Line.Color = Color
		Line.Visible = true 

		Line2.From = Vector2.new(x + 4, y - 4)
		Line2.To = Vector2.new(x + 10, y - 10)
		Line2.Color = Color
		Line2.Visible = true 

		Line3.From = Vector2.new(x - 4, y - 4)
		Line3.To = Vector2.new(x - 10, y - 10)
		Line3.Color = Color
		Line3.Visible = true 

		Line4.From = Vector2.new(x - 4, y + 4)
		Line4.To = Vector2.new(x - 10, y + 10)
		Line4.Color = Color
		Line4.Visible = true

		Line.Transparency = 1
		Line2.Transparency = 1
		Line3.Transparency = 1
		Line4.Transparency = 1

		Line.Thickness = 1
		Line2.Thickness = 1
		Line3.Thickness = 1
		Line4.Thickness = 1

		spawn(function()
			while Line ~= nil do
				wait()
				local vector, onScreen = Local.Camera:WorldToViewportPoint(pos)
				x, y = vector.X, vector.Y

				Line.From = Vector2.new(x + 4, y + 4)
				Line.To = Vector2.new(x + 10, y + 10)
				Line.Color = Color
				Line.Visible = true 

				Line2.From = Vector2.new(x + 4, y - 4)
				Line2.To = Vector2.new(x + 10, y - 10)
				Line2.Color = Color
				Line2.Visible = true 

				Line3.From = Vector2.new(x - 4, y - 4)
				Line3.To = Vector2.new(x - 10, y - 10)
				Line3.Color = Color
				Line3.Visible = true 

				Line4.From = Vector2.new(x - 4, y + 4)
				Line4.To = Vector2.new(x - 10, y + 10)
				Line4.Color = Color
				Line4.Visible = true

				if not onScreen then
					Line.Transparency = 0
					Line2.Transparency = 0
					Line3.Transparency = 0
					Line4.Transparency = 0
				end
			end
		end)

		wait(.3)
		for i = 1,0,-.1 do
			wait()
			Line.Transparency = i 
			Line2.Transparency = i
			Line3.Transparency = i
			Line4.Transparency = i
		end
		Line:Remove()
		Line2:Remove()
		Line3:Remove()
		Line4:Remove()
	end
end

EV:AddDropdown("Skybox", indexOf(SkyboxesTable, Settings.Skybox), SkyboxesTable, function(d)
	Settings.Skybox = d
	if d == "None" then
		Skybox.Parent = nil
	else
		Skybox.Parent = Services.Lighting
		local sb = Skyboxes[d]
		Skybox.CelestialBodiesShown = false
		Skybox.SkyboxLf = sb.SkyboxLf
		Skybox.SkyboxBk = sb.SkyboxBk
		Skybox.SkyboxDn = sb.SkyboxDn
		Skybox.SkyboxFt = sb.SkyboxFt
		Skybox.SkyboxLf = sb.SkyboxLf
		Skybox.SkyboxRt = sb.SkyboxRt
		Skybox.SkyboxUp = sb.SkyboxUp
		Skybox.StarCount = sb.StarCount
	end
end)

EV:AddSlider("Lighting time", 24, Settings.ClockTime, function(v)
	Settings.ClockTime = v
	Services.Lighting.ClockTime = v
end, 0.01)

EV:AddToggle("Fullbright", Settings.Fullbright, function(b)
	Settings.Fullbright = b
	if b then
		Services.Lighting.Ambient = Color3.new(1,1,1)
		Services.Lighting.Brightness = 0
	else
		Services.Lighting.Ambient = Color3.new(0,0,0)
		Services.Lighting.Brightness = 2
	end
end)

spawn(function()
	workspace:WaitForChild("Ray_Ignore"):WaitForChild("Smokes").DescendantAdded:connect(function(v)
		if Settings.RemoveSmoke then
			v:Remove()
		end
		if Settings.WireframeSmoke then
			if v:IsA("ParticleEmitter") then 
				v.Texture = "rbxassetid://65437818"
				v.Size = NumberSequence.new(0, 10)
				v.Transparency = NumberSequence.new(0.9)
				v.SpreadAngle = Vector2.new(0, 0)
				v.Rate = 20
				v.Acceleration = Vector3.new(0,0,0)
				v.Lifetime = NumberRange.new(5, 10)
				v.Speed = NumberRange.new(0)
				v.RotSpeed = NumberRange.new(10,100)
			end		
			if v:IsA("Part") then
				v.Transparency = 1
			end
		end
	end)
end)

spawn(function()
	while wait() do
		local SpectatePlayer = nil
		if isAlive(Local.Player) then
			SpectatePlayer = Local.Player
		else
			local SpectatePlayer = Local.PlayerGui.GUI.Spectate.Current.Value
			if SpectatePlayer and SpectatePlayer ~= "" and SpectatePlayer ~= nil and Services.Players:FindFirstChild(SpectatePlayer) then
				SpectatePlayer = Services.Players[SpectatePlayer]
			end
		end

		function disable(v)
			PlayerListInfo[v.UserId].SpectatorDot.Visible = false
			PlayerListInfo[v.UserId].SpectatorText.Visible = false
			SpectateEntries[v.Name].Visible = false
		end
		pcall(function()
			for i,v in pairs(Services.Players:GetPlayers()) do
				if not isAlive(v) then
					local cf = v.CameraCF.Value
					local vector, onScreen = Local.Camera:WorldToScreenPoint(cf.p)
					if onScreen then
						PlayerListInfo[v.UserId].SpectatorDot.Visible = true
						PlayerListInfo[v.UserId].SpectatorText.Visible = true
						PlayerListInfo[v.UserId].SpectatorDot.Position = Vector2.new(vector.X, vector.Y)
						PlayerListInfo[v.UserId].SpectatorText.Position = Vector2.new(vector.X, vector.Y + 18)
					else
						PlayerListInfo[v.UserId].SpectatorText.Visible = false
						PlayerListInfo[v.UserId].SpectatorDot.Visible = false
					end
					if SpectatePlayer and SpectatePlayer.Character:FindFirstChild("HumanoidRootPart") and Settings.SpectatorUI  then
						local d = GetDistanceSq(SpectatePlayer.Character:FindFirstChild("HumanoidRootPart").CFrame.p, cf.p) -- SQUARED DISTANCE FOR EFFICIENCY
						if d < 50 then -- 5^2 = 25
							--First person
							SpectateEntries[v.Name].Visible = true
							SpectateEntries[v.Name].OBSM.Text = "Firstperson"
						elseif d < 100 then --10^2 = 100
							--thirdperson
							SpectateEntries[v.Name].Visible = true
							SpectateEntries[v.Name].OBSM.Text = "Thirdperson"
						else
							--not spectating us
							SpectateEntries[v.Name].Visible = false
						end
					else
						disable(v)
					end
				else
					disable(v)
				end
			end
		end)
	end
end)


spawn(function()
	local Stats = game:GetService("Stats")
	local Heartbeat = game:GetService("RunService").Heartbeat

	local LastIteration, Start
	local FrameUpdateTable = { }
	local floor = math.floor
	local function HeartbeatUpdate()
		LastIteration = tick()
		for Index = #FrameUpdateTable, 1, -1 do
			FrameUpdateTable[Index + 1] = (FrameUpdateTable[Index] >= LastIteration - 1) and FrameUpdateTable[Index] or nil
		end
		
		FrameUpdateTable[1] = LastIteration
		local CurrentFPS = (tick() - Start >= 1 and #FrameUpdateTable) or (#FrameUpdateTable / (tick() - Start))
		CurrentFPS = floor(CurrentFPS )
		setLetters("Qual Beta | "..CurrentFPS.." fps | "..floor(Stats:GetTotalMemoryUsageMb()).." MB | "..Stats.InstanceCount.." Objects")
	end
	
	Start = tick()
	Heartbeat:Connect(HeartbeatUpdate)
end)



spawn(function()
	local hue = 0
	while wait() do
		if Settings.Watermark then
			hue = hue + 1
			for i,v in pairs(letters) do
				v.TextColor3 = Color3.fromHSV(((hue / 59) + (i / 59)) % 1, 1, 1)
			end
		end
	end
end)


Camera:AddSlider("Thirdperson Distance", 20, Settings.ThirdpersonDistance, function(v)
	Settings.ThirdpersonDistance = v
end)

local AlliesESPtab = Core:CreateTab("Ally ESP")
local EnemiesESPtab = Core:CreateTab("Enemy ESP")

local GameCheats = Core:CreateTab("GameCheats")
local PlayerCheats = Core:CreateTab("PlayerCheats")

local Skins = PlayerCheats:AddLocalTab("Skins (NOT FE)")
local AA = PlayerCheats:AddLocalTab("Antiaim")
local AE = PlayerCheats:AddLocalTab("Antienvironment")
local RV = PlayerCheats:AddLocalTab("Revolver")
local Bunnyhop = PlayerCheats:AddLocalTab("Bunnyhopping")
local PCMisc = PlayerCheats:AddLocalTab("Misc")

local BM = GameCheats:AddLocalTab("Buy Menu")
local ChatTab = GameCheats:AddLocalTab("Chat")
local HN = GameCheats:AddLocalTab("Hide Name (CLIENT)")
local PS = GameCheats:AddLocalTab("FE Play Sounds")
local LagSpike = GameCheats:AddLocalTab("Lagspike / Ragecrash")


local Obj = PlayerCheats:AddLocalTab("Objective")
local Fun = PlayerCheats:AddLocalTab("Fun")


for tab,team in pairs({[AlliesESPtab] = "Allies", [EnemiesESPtab] = "Enemies"}) do
	for i,v in pairs({"Inner", "Outer"}) do
		local ChamsTab = tab:AddLocalTab(v.." Chams")

		ChamsTab:AddToggle("Enabled", Settings[v.."Chams"][team].Render, function(b)
			Settings[v.."Chams"][team].Render = b
			ESP()
		end)

		ChamsTab:AddCP("Color", Settings[v.."Chams"][team].Color, function(c3, alpha)
			Settings[v.."Chams"][team].Color = c3
			if alpha then
				Settings[v.."Chams"][team].Transparency = alpha
			end
			ESP()
		end, Settings[v.."Chams"][team].Transparency)
		
		ChamsTab:AddToggle("Use Team Color Instead", Settings[v.."Chams"][team].UseTeamColor, function(b)
			Settings[v.."Chams"][team].UseTeamColor = b
			ESP()
		end)

		ChamsTab:AddToggle("Render Only While Visible", Settings[v.."Chams"][team].VisibleOnly, function(b)
			Settings[v.."Chams"][team].VisibleOnly = b
			ESP()
		end)

		if v == "Outer" then
			ChamsTab:AddSlider("Size", 5, Settings.OuterChams[team].Size, function(n)
				Settings.OuterChams[team].Size = n
				ESP()
			end, 0.01)
		end
	end

	local Boxes = tab:AddLocalTab("Boxes")

	Boxes:AddToggle("Render Boxes", Settings.Boxes[team].Enabled, function(b)
		Settings.Boxes[team].Enabled = b
	end)

	Boxes:AddCP("Color", Settings.Boxes[team].Color, function(c3, alpha)
		Settings.Boxes[team].Color = c3
		Settings.Boxes[team].Transparency = alpha
	end, Settings.Boxes[team].Transparency)

	local Healthbar = tab:AddLocalTab("Healthbar")

	Healthbar:AddToggle("Render Healthbar", Settings.Healthbar[team].Enabled, function(b)
		Settings.Healthbar[team].Enabled = b
	end)
	
	Healthbar:AddCP("Color", Settings.Healthbar[team].Color, function(c3)
		Settings.Healthbar[team].Color = c3
	end)

	local Tracers = tab:AddLocalTab("Tracers")

	Tracers:AddToggle("Render Tracers", Settings.Tracers[team].Enabled, function(b)
		Settings.Tracers[team].Enabled = b
	end)

	Tracers:AddCP("Color", Settings.Tracers[team].Color, function(c3, alpha)
		Settings.Tracers[team].Color = c3
		Settings.Tracers[team].Transparency = alpha
	end, Settings.Tracers[team].Transparency)

	local WeaponText = tab:AddLocalTab("Weapon Text")

	WeaponText:AddToggle("Render Weapon Text", Settings.WeaponText[team].Enabled, function(b)
		Settings.WeaponText[team].Enabled = b
	end)

	WeaponText:AddCP("Color", Settings.WeaponText[team].Color, function(c3, alpha)
		Settings.WeaponText[team].Color = c3
		Settings.WeaponText[team].Transparency = alpha
	end, Settings.WeaponText[team].Transparency)

	local Nametags = tab:AddLocalTab("Nametags")

	Nametags:AddToggle("Render Nametags", Settings.Nametags[team].Enabled, function(b)
		Settings.Nametags[team].Enabled = b
	end)
	
	Nametags:AddCP("Color", Settings.Nametags[team].Color, function(c3, alpha)
		Settings.Nametags[team].Color = c3
		Settings.Nametags[team].Transparency = alpha
	end, Settings.Nametags[team].Transparency)

	local BombText = tab:AddLocalTab("Bomb Text")

	BombText:AddToggle("Render Bomb Text", Settings.BombText[team].Enabled, function(b)
		Settings.BombText[team].Enabled = b
	end)
	
	BombText:AddCP("Color", Settings.BombText[team].Color, function(c3, alpha)
		Settings.BombText[team].Color = c3
		Settings.BombText[team].Transparency = alpha
	end, Settings.BombText[team].Transparency)
end

Skins:AddToggle("Unlock All Skins", Settings.SkinChanger, function(b)
	Settings.SkinChanger = b
	if b then
		Local.Game.CurrentInventory = Skin
	end
end)
--[[
Skins:AddButton("Randomize Skins", function()
	for i,t in pairs({"T", "CT"}) do
		for i,v in pairs(Local.Player.SkinFolder[t.."Folder"]:GetChildren()) do
			local s
			local CI = Local.Game.CurrentInventory
			repeat 
				wait()
				s = math.random(1, #CI)
			until CI[s][1]:find("^"..v.Name) ~= nil
			
			Local.Game.equipitem(s, t)
		end
	end
end)]]

JNegative = false
JRotation = false
Jitter = 0

AA:AddToggle("Enabled", Settings.AA.Enabled, function(b)
	Settings.AA.Enabled = b
end)

AA:AddSlider("Pitch", 2, Settings.AA.Pitch, function(v)
	Settings.AA.Pitch = v
	Events.ControlTurn:FireServer(v, false)
end, 0.01)

AA:AddSlider("Jitter Speed", 45, Settings.AA.JSpeed, function(v)
	Settings.AA.JSpeed = v
end, 0.1)

AA:AddSlider("Jitter Range", 360, Settings.AA.JRange, function(v)
	Settings.AA.JRange = v
end, 0.1)

AA:AddKeybind("Inverse Jitter Direction", Enum.KeyCode[Settings.AA["JDirection"]], function()
	JNegative = not JNegative
end, false)

AA:AddKeybind("Inverse Jitter Rotation", Enum.KeyCode[Settings.AA["JRotation"]], function()
	JRotation = not JRotation
end, false)

AA:AddToggle("Become Invisible", Settings.AA.Invisible, function(b)
	Settings.AA.Invisible = b
end)

DirectionMode = {"None", "Nearest", "All Threats", "Manual"}
AA:AddDropdown("Direction", indexOf(DirectionMode, Settings.AA.Direction), DirectionMode, function(d)
	pcall(function()
		if d == "None" then
			Local.Player.Character.Humanoid.AutoRotate = true
		end
	end)
	Settings.AA.Direction = d
end)

Direction = ""

for i,v in pairs({"Left", "Back", "Right"}) do
	AA:AddKeybind(v, Enum.KeyCode[Settings.AA[v]], function()
		if Direction == v then
			Direction = ""
		else
			Direction = v
		end
	end, false)
end

AA:AddToggle("Remove Head", Settings.RHead, function(b)
	Settings.RHead = b
end)

AE:AddToggle("Remove Fall Damage", Settings.NoFall, function(b)
	Settings.NoFall = b
end)

AE:AddToggle("Remove Fire Damage", Settings.AntiMolotov, function(b)
	Settings.AntiMolotov = b
end)

AE:AddToggle("Remove Flashes", Settings.RemoveFlash, function(b)
	Settings.RemoveFlash = b
	Local.PlayerGui.Blnd.Enabled = not b
	Local.PlayerGui.GUI.Blind.Visible = not b
end)

AE:AddToggle("Wireframe Smokes", Settings.WireframeSmoke, function(b)
	Settings.WireframeSmoke = b
end)

AE:AddToggle("Remove Smokes", Settings.RemoveSmoke, function(b)
	Settings.RemoveSmoke = b
end)

AE:AddKeybind("Noclip", Enum.KeyCode[Settings.Noclipkey], function()
	Settings.Noclip = not Settings.Noclip
end, false)

RV:AddToggle("Make revolver instant", Settings.InstaRev, function(b)
	Settings.InstaRev = b
end)

RV:AddToggle("Play animation constantly", Settings.RevAnimate, function(b)
	Settings.RevAnimate = b
end)

Bunnyhop:AddToggle("Autohop", Settings.Autohop, function(b)
	Settings.Autohop = b
end)

Bunnyhop:AddToggle("Legit Autostrafe", Settings.LegitStrafe, function(b)
	Settings.LegitStrafe = b
end)

Bunnyhop:AddSlider("Autostrafe Speed", 100, Settings.AutohopSpeed, function(n)
	Settings.AutohopSpeed = n
end)

Bunnyhop:AddSlider("Autohop hit percentage", 100, Settings.AutohopHitrate, function(n)
	Settings.AutohopHitrate = n
end)

PCMisc:AddToggle("Infinite Grenades", Settings.InfNades, function(b)
	Settings.InfNades = b
end)

PCMisc:AddToggle("Fakeduck", Settings.Fakeduck, function(b)
	Settings.Fakeduck = b
end)

BM:AddToggle("Buymenu Anywhere", Settings.Buymenu, function(b)
	Settings.Buymenu = b
end)

BM:AddToggle("Infinite Cash", Settings.InfiniteCash, function(b)
	Settings.InfiniteCash = b
	if not b then
		Local.Player.Cash.Value = 5000
        Local.PlayerGui.GUI.Cash.Text = "$5000"
	end
end)

BM:AddToggle("Buy any 4 grenades", Settings.RemoveGrenadeLogic, function(b)
	Settings.RemoveGrenadeLogic = b
end)

Fun:AddToggle("Make head blocky", Settings.Blockhead, function(b)
	Settings.Blockhead = b
end)

Fun:AddToggle("Make hats blocky", Settings.Blockhats, function(b)
	Settings.Blockhats = b
end)

Fun:AddToggle("Remove Clothes", Settings.Naked, function(b)
	Settings.Naked = b
end)

Fun:AddToggle("Remove Limbs (VERY BUGGY)", Settings.RLimbs, function(b)
	Settings.RLimbs = b
end)

HN:AddToggle("Hide Name", Settings.HideName, function(b)
	Settings.HideName = b
end)

HN:AddBox("Killsay Message", Settings.Name, function(v)
	Settings.Name = v
end)

for j,k in pairs({workspace, workspace.Sounds}) do
	for i,v in pairs(k:GetChildren()) do
		if v:IsA("Sound") then
			local bool = false
			PS:AddToggle("Play "..v.Name, false, function(b)
				bool = b
				if bool then
					v.Playing = true
				end
			end)
			v.Ended:connect(function()
				if bool then
					v.Playing = true
				end
			end)
		end
	end
end

spawn(function()
	repeat wait() until Local.Game.speedupdate
	
	local speedupdate = Local.Game.speedupdate
	Local.Game.speedupdate = function()
		if Services.UserInputService:IsKeyDown(Enum.KeyCode.Space) and isAlive(Local.Player) and Services.UserInputService:GetFocusedTextBox() == nil and Settings.Autohop then
			Local.Player.Character.Humanoid.Jump = true
			if not Storage.AutohopHit then
				return speedupdate()
			end
			if Settings.LegitStrafe then
				Local.Player.Character.Humanoid.WalkSpeed = Settings.AutohopSpeed
			else
				Local.Player.Character.Humanoid.WalkSpeed = lerp(Local.Player.Character.Humanoid.WalkSpeed, Settings.AutohopSpeed, 0.01)
			end
			
			return
		end
		return speedupdate()
	end
end)

function mapSkin(gun, gn, skin)
	local skindataf = skin
	if skindataf ~= nil then
		local skin = skindataf
		if skin ~= "Stock" then
			do
				local whichskin = gn
				if string.find(string.lower(gn), "falchion") then
					whichskin = "Falchion Knife"
				end
				if string.find(string.lower(gn), "bayonet") then
					whichskin = "Bayonet"
				end
				if string.find(string.lower(gn), "huntsman") then
					whichskin = "Huntsman Knife"
				end
				if string.find(string.lower(gn), "butterfly") then
					whichskin = "Butterfly Knife"
				end
				if string.find(string.lower(gn), "gut") then
					whichskin = "Gut Knife"
				end
				if string.find(string.lower(gn), "karambit") then
					whichskin = "Karambit"
				end
				local skindata = game.ReplicatedStorage.Skins[whichskin][skin]
				if not skindata:FindFirstChild("Animated") then
					local skindatach = skindata:GetDescendants()
					for _, v in pairs(skindatach) do
						pcall(function()
							if gun:FindFirstChild(v.Name) and gun[v.Name].Transparency == 0 then
								if not gun[v.Name]:FindFirstChild("Mesh") then
									pcall(function()
										gun[v.Name].TextureID = v.Value
									end)
								elseif gun[v.Name]:FindFirstChild("Mesh") then
									pcall(function()
										gun[v.Name].Mesh.TextureId = v.Value
									end)
								end
							end
						end)
					end
				else
					do
						local textures = require(skindata.Animated)
						local function findTexture(texture)
							for _, v in pairs(textures) do
								if v == texture then
									return true
								end
							end
							return false
						end
						coroutine.wrap(function()
							repeat
								wait()
							until gun.Parent
							while gun and gun.Parent do
								for i = 1, #textures do
									if gun and gun.Parent and findTexture(textures[i]) then
										if skindata.Name == "Candy Cane" then
											gun.Handle.TextureID = textures[i]
										elseif skindata.Name == "Late Night" then
											gun.Blade.TextureID = textures[i]
											gun["1Handle"].TextureID = textures[i]
										end
									end
									wait(textures.delays)
								end
								wait(textures.delays)
							end
						end)()
					end
				end
			end
		end
	end
end

do -- ui skin handler
	for i = 1,3 do
		local wep = Local.Game.weapons[i]
		wep.ToolName:GetPropertyChangedSignal("Text"):connect(function()
			wait()
			local gn
			if i == 1 then
				gn = Local.Game.primary
			elseif i == 2 then
				gn = Local.Game.secondary
			elseif i == 3 then
				gn = Local.Game.melee
			end
			--print(gn)
			if FESkins[gn] then
				print("YES")
				wep.ToolName.Text = gn.." | "..FESkins[gn][3]
				wep.ToolName.TextColor3 = FESkins[gn][4]
				wep.Weapon.ImageColor3 = FESkins[gn][4]
			end
		end)
	end
end

spawn(function()
	repeat wait() until Local.Game.usethatgun
	
	cantdumpthis = Local.Game.usethatgun

	Local.Game.usethatgun = function(owner)
		if Local.Game.gun and Local.Game.gun ~= "none" then
			local gn = Local.Game.gun.Name
			if gn:find("Knife") then
				gn = "Knife"
			end
			if FESkins[gn] and owner and owner.Name == Local.Player.Name then
				local v = Services.Players:FindFirstChild(FESkins[gn][1])
				if v then
					spawn(function()
						Local.Camera.ChildAdded:Wait()
						wait()
						local arms = Local.Camera:WaitForChild("Arms")
						mapSkin(arms, Local.Game.gun.Name, FESkins[gn][3])
					end)
					wait()
					cantdumpthis(v)
					local skindata = game.ReplicatedStorage.Skins:FindFirstChild(Local.Game.gun.Name)
					return
				else
					FESkins[gn] = nil
				end
			end
		end
		cantdumpthis(owner)
		Local.Game.fireani:GetPropertyChangedSignal("IsPlaying"):connect(function()
			if Local.Game.fireani.IsPlaying and Local.Game.gun.Name == "C4" and Settings.Instaplant then
				wait()
				print("instaplanting")
				Events.PlantC4:FireServer(CFrame.new(Local.Player.Character.HumanoidRootPart.Position + Vector3.new(0,-2,0))*CFrame.Angles(0,0,4), getSite())
				Local.Game.fireani:Stop()
			end
		end)
		return
	end
end)

grenadeallowed = Local.Game.grenadeallowed
Local.Game.grenadeallowed = function(AAA)
	if Settings.RemoveGrenadeLogic then
		return true
	end
	return grenadeallowed(AAA)
end

ChatTab:AddToggle("Remove Chat Filter", Settings.Unhash, function(b)
	Settings.Unhash = b
end)

ChatTab:AddToggle("See All Chat", Settings.AllChat, function(b)
	Settings.AllChat = b
end)

ChatTab:AddToggle("Chat as always alive", Settings.ChatAlive, function(b)
	Settings.ChatAlive = b
end)

ChatTab:AddBox("Flood Chat Message", Settings.Chat1, function(v)
	Settings.Chat1 = v
end)

ChatTab:AddSlider("Messages per frame", 400, Settings.FloodMessages, function(n)
	Settings.FloodMessages = n
end)

ChatTab:AddToggle("Spam Chat", false, function(b)
	if b then
		Storage.Chatcrash = Services.RunService.RenderStepped:connect(function()
			for i = 1,Settings.FloodMessages do
				Chat(Settings.Chat1)
			end
		end)
	elseif Storage.Chatcrash then
		Storage.Chatcrash:disconnect()
	end
end)


function DropGun(gun, cf, owner)
    if game:GetService("ReplicatedStorage").Warmup.Value == true then return end
    Events.Drop:FireServer(gun, cf, 999999999999999999, 999999999999999999, false, owner, false, false)
end

LagSpike:AddSlider("Lag Severity / Length", 10, Settings.LagSeverity, function(n)
	Settings.LagSeverity = n
end)

LagSpike:AddButton("Lagspike", function()
	for i = 1,Settings.LagSeverity*Settings.LagSeverity do
		for i,v in pairs(Weapons.Path:GetChildren()) do
			if v:IsA("Folder") then
				DropGun(v, CFrame.new(0, -999999999999999999, 0), nil)
			end
		end
	end
end)

LagSpike:AddButton("Ragecrash", function()
	S:Connect(function()
		local oh1 = Weapons.Path.Molotov.Model
		local oh3 = 25
		local oh4 = 35
		local oh6 = ""
		local oh7 = ""
		for i = 1,3 do
			Events.ThrowGrenade:FireServer(oh1, nil, oh3, oh4, Vector3.new(0,-100,0), oh6, oh7)
		end
	end)
end)


ChatTab:AddBox("Killsay Message", Settings.Chat2, function(v)
	Settings.Chat2 = v
end)

ChatTab:AddToggle("Killsay", Settings.Killsay, function(b)
	Settings.Killsay = b
end)

Obj:AddToggle("Antidefuse", Settings.Antidefuse, function(b)
	Settings.Antidefuse = b
end)

Obj:AddToggle("Instaplant", Settings.Instaplant, function(b)
	Settings.Instaplant = b
end)

Obj:AddButton("Capture Hostage", function()
	if not isAlive(Local.Player) then return end
	if not workspace.Map.Gamemode.Value == "defusal" then
        Local.Player.Backpack.Defuse:FireServer(workspace.Map.Regen.Hostages.Hostage)
    end
end)

spawn(function()
	while wait(0.2) do
		if isAlive(Local.Player) and Local.Player.Character and Local.Player.Character:FindFirstChild("EquippedTool") and Local.Player.Character.EquippedTool.Value == "R8" and Local.Player.Character:FindFirstChild("Gun") and Settings.RevAnimate then
			Local.Player.Character.Gun.unpull:Play()
			Local.Game.pullani:Play(nil, nil, 0.65)
			Local.Player.Character.Gun.pull:Play()
		end
	end
end)


lastEquipped = nil

function getStatus(v)
	local Player = PlayerListInfo[v.UserId]
	if not Player then return Settings.DefaultBot end
	local stat = Player.Status
	if stat == "Auto" then
		stat = Settings.DefaultBot
	end
	return stat
end

function NoclipLoop()
	Local.Player.Character.Humanoid:ChangeState(11)
end

spawn(function()
	while wait() do
		for i,v in pairs(Services.Players:GetPlayers()) do
			local stat = getStatus(v)
			stat = Settings[stat]
			if v.Team ~= Local.Player.Team and isAlive(v) and stat and stat.Backtrack then
				local bss = BacktrackSample:clone()
				for _,o in pairs(v.Character:GetChildren()) do
					local p = bss:FindFirstChild(o.Name)
					if p then
						p.Name = "nowallbang"
						p.CFrame = o.CFrame
						if not stat.BacktrackRainbow then
							p.Color = stat.BacktrackColor
						else
							p.Color = Rainbow(2,1,1)
						end
						p.Transparency = stat.BacktrackTransparency
						br = Instance.new("ObjectValue", p)
						br.Name = "PT"
						br.Value = o
						Services.Debris:AddItem(p, stat.BacktrackDelay/1000)
					end
				end
				bss.Parent = Backtrack
			end
		end
	end
end)

yaw = 0

--main loop
S:connect(function()
	if not isAlive(Local.Player) or not Local.Player.Character then 
		return 
	end

	local Player = Local.Player
	local Character = Local.Player.Character

	if Settings.InfiniteCash then
		Local.Player.Cash.Value = 5500
		Local.PlayerGui.GUI.Cash.Text = "$inf"
	end

	if Spectatorkey.holding then
		Local.Camera.CFrame = Local.Player.CameraCF.Value
	end
	Storage.Target = CalculateAimbot()
	--[[local Cache
	if Storage.Target then
		Cache = Storage.Target[2].Name
	else
		Cache = nil
	end
	
	if Storage.Target and Cache ~= Storage.Target[2].Name then
		--PlaySound(538769304, 0, 1/4)
	end]]
	local Target = Storage.Target
	if Target then
		local sTarget = Settings[Target[2]]
		if sTarget and sTarget.AimbotStyle == "Track target" then
			Local.Camera.CFrame = CFrame.new(Local.Camera.CFrame.p, Storage.Target[1][1])
		end
		if sTarget and sTarget.Shootbot and Local.Game.gun ~= "none" then
			local ourCFrame = AimbotFunctions.getRealCameraVector(Local.Player.Character)
			local hit, hitpos, dm, wb = AimbotFunctions.SimulateShot(CFrame.new(ourCFrame, Storage.Target[1][1]), Target[3].Character)
			if hit then
				local dmg = Local.Game.gun.DMG.Value * dm
				local wbthing = not wb or (wb and sTarget.Autowall)
				if (dmg > (wb and sTarget.MinAWDamage or sTarget.MinVisibleDamage)) and wbthing then
					mouse1press()
					wait(0.04)
					mouse1release()
				end
			end
		end
	end

	if Settings.Noclip then
		NoclipLoop()
	end
	
	--[[if Settings.RHead and Character:FindFirstChild("FakeHead") then
		Character.FakeHead:Remove()
	end]]
	
	if Settings.RHead and Character:FindFirstChild("HeadHB") then
		Character.HeadHB:Remove()
		Character.FakeHead:Remove()
	end

	if not Settings.RHead and Settings.Blockhead and Character.FakeHead:FindFirstChild("Mesh") then
		Character.FakeHead.Mesh:Remove()
	end

	if Settings.Naked and Character:FindFirstChildOfClass("Shirt") then
		for i,v in pairs(Character:GetDescendants()) do
			if v:IsA("Clothing") then
				v:Destroy()
			end
		end
	end
	pcall(function()
		if Settings.Blockhats then
			for _,v in pairs(Character:GetChildren()) do
				if v:IsA("Accessory") then
					v.Handle.Mesh:Destroy()
				end
			end
		end
	end)

	if Settings.RLimbs and Character:FindFirstChild("RightUpperArm") then
		for i,v in pairs(Character:GetChildren()) do
			if v:IsA("BasePart") and
				v.Name == "RightUpperLeg" or
				v.Name == "LeftUpperLeg" or
				v.Name == "RightUpperArm" or
				v.Name == "LeftUpperArm" then
				v:Destroy()
			end
		end
	end
	
	if Settings.AA.Invisible and Character.LowerTorso:FindFirstChild("Root") then
		local hrp = Character:FindFirstChild("HumanoidRootPart")
		if hrp then
			local storedpos = hrp.CFrame
			hrp.CFrame = CFrame.new(0,9e12,0)
			wait(1)
			Character.LowerTorso.Root:Remove()
			wait(1)
			hrp.CFrame = storedpos
		end
	end

	local current = Character:FindFirstChild("EquippedTool")
	if current and current.Value ~= lastEquipped then
		lastEquipped = current.Value
		doSelfChams()
	end
end)

local PList = UI:CreateWindow("Player List", Vector2.new(600, 430), Vector2.new(540, 40)) --fucking ignore this shit holy fuck this row shit
local Players = PList:CreateTab("Players")
local Outfits = PList:CreateTab("Outfits")
OutfitScroll.Parent = Outfits.main
UIListLayout.Parent = Players.main
UIPadding.Parent = Players.main
TT.Parent = Players.main
SFrame.Parent = Players.main
Container.BackgroundTransparency = 1
Container.Parent = Players.main
Container.Size = UDim2.new(1, -20, 0, 170)
local ClickedName = nil
local Info = Players:AddLocalTab("Player Info")
local Name = Info:AddLabel("Name: ")
local UID = Info:AddLabel("UserID: ")
local RGroup = Info:AddLabel("Is in ROLVe Group: ")
local IAlive = Info:AddLabel("Is Alive: ")
local Pos = Info:AddLabel("Position: ")
local Ang = Info:AddLabel("Angles: ")
local Cash = Info:AddLabel("Cash: ")
local LOM = Info:AddLabel("Legit-o-meter: ")
Players.row.Parent = Container
Players.row.Size = UDim2.new(0.5, 0, 1, 0)
local Controls = Players:AddLocalTab("More Info + Controls")
Players.row.Parent = Container
Players.row.Size = UDim2.new(0.5, 0, 1, 0)
local Funds = Controls:AddLabel("Credits: ")
local Tier = Controls:AddLabel("Current Battlepass Tier: ")
local OutfitsButton = Controls:AddButton("View Outfits", function()
	if ClickedName == nil then return end
	for i,v in pairs(OBack:GetChildren()) do
		if v:IsA("Frame") then
			v:Destroy()
		end
	end

	local data = game:HttpGet("https://avatar.roblox.com/v1/users/"..ClickedName.UserId.."/outfits")
	local json = Services.HttpService:JSONDecode(data)
	for i,o in pairs(json.data) do
		AddOutfit(o.id, o.name)
	end
	Outfits:clicked()
end)

local SkinTab = PList:CreateTab("FE Skins")

Instance.new("UIListLayout", SkinTab.main)
FESkin.Parent = SkinTab.main
SkinScroll.Parent = SkinTab.main

local Pictures = Players:AddLocalTab("Avatar Pictures")
Pictures.layout.FillDirection = Enum.FillDirection.Horizontal
for i = 1,3 do
	local IL = Instance.new("ImageLabel", Pictures.content)
	IL.BackgroundColor3 = UI.colors.tabselected
	IL.BorderColor3 = Color3.new()
	IL.Image = "rbxassetid://290996577"
	IL.Size = UDim2.new(0,82,0,82)
	Pictures.main.Size = UDim2.new(1,0,0, Pictures.layout.AbsoluteContentSize.Y+20)
end

local WeaponMods = UI:CreateWindow("Weapon Modifications", Vector2.new(450, 308), Vector2.new(1180, 40))

starting_debounce = false
for i,v in pairs(Weapons.Types) do
	local BulletOverride = false
	local tab = WeaponMods:CreateTab(v)
	local FR = tab:AddLocalTab("Firerate")
	FR:AddSlider("Firerate Multiplier", 5, 1, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value = Weapon:FindFirstChild("FireRate")
				local OldValue = Old:FindFirstChild("FireRate")
				if Value and value then
					Value.Value = OldValue.Value / value
				elseif Value then
					Value.Value = OldValue.Value
				end
			end
		end
	end, 0.1)
	
	local RT = tab:AddLocalTab("Reload Time")
	RT:AddSlider("Reduce Reload Time", 5, 1, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value = Weapon:FindFirstChild("ReloadTime")
				local OldValue = Old:FindFirstChild("ReloadTime")
				if Value then
					Value.Value = OldValue.Value / value
				elseif Value then
					Value.Value = OldValue.Value
				end
			end
		end
	end, 0.1)
	
	local IA = tab:AddLocalTab("Infinite Ammo")
	IA:AddToggle("Infinite Ammo", false, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value1 = Weapon:FindFirstChild("StoredAmmo")
				local OldValue1 = Old:FindFirstChild("StoredAmmo")
				local Value2 = Weapon:FindFirstChild("Ammo")
				local OldValue2 = Old:FindFirstChild("Ammo")
				if value then
					if Value1 then
						Value1.Value = 9e12
					end
					if Value2 then
						Value2.Value = 9e9
					end
				else
					if Value1 then
						Value1.Value = OldValue1.Value
					end
					if Value2 then
						Value2.Value = OldValue2.Value
					end
				end
			end
		end
	end)
	
	local FA = tab:AddLocalTab("Force Auto")
	FA:AddToggle("Force Auto", false, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Value = Weapon:FindFirstChild("Auto")
				if Value then
					Value.Value = value
				end
			end
		end
	end)
	
	local RT = tab:AddLocalTab("Force Shotgun")
	RT:AddToggle("Enable Bullet Override", false, function(value)
		if starting_debounce then
			BulletOverride = value
			if not value then
				for i,v in pairs(Weapons[v]) do
					local Weapon = Weapons.Path[v]
					local Old = Weapons.Old[v]
					local Value = Weapon:FindFirstChild("Bullets")
					local OldValue = Old:FindFirstChild("Bullets")
					if Value then
						Value.Value = OldValue.Value
					end
				end
			end
		end
	end)
	
	RT:AddSlider("Bullets to shoot", 100, 1, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value = Weapon:FindFirstChild("Bullets")
				local OldValue = Old:FindFirstChild("Bullets")
				if Value and BulletOverride and Value:FindFirstChild("Value") then
					Value.Value = value
				else
					Value.Value = OldValue.Value
				end
			end
		end
	end)
	
	local IE = tab:AddLocalTab("Instant Equip")
	IE:AddToggle("Instant Equip", false, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value = Weapon:FindFirstChild("EquipTime")
				local OldValue = Old:FindFirstChild("EquipTime")
				if Value and value then
					Value.Value = 0
				elseif Value then
					Value.Value = OldValue.Value
				end
			end
		end
	end)
	
	local RT = tab:AddLocalTab("RCS and Spread")
	RT:AddSlider("Reduce Spread", 1, 0, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				local Weapon = Weapons.Path[v]
				local Old = Weapons.Old[v]
				local Value = Weapon:FindFirstChild("Spread")
				local OldValue = Old:FindFirstChild("Spread")
				if Value then
					Value.Value = OldValue.Value * (1-value)
					for _,children in pairs(Value:GetChildren()) do
						children.Value = OldValue[children.Name].Value * (1-value)
					end
				end
			end
		end
	end, 0.01)
	
	RT:AddSlider("Reduce Recoil", 1, 0, function(value)
		if starting_debounce then
			for i,v in pairs(Weapons[v]) do
				Storage[v] = (1-value)
			end
		end
	end, 0.01)
end

starting_debounce = true

function AddOutfit(Id, Name)
	local Frame = Instance.new("Frame")
	local ImageLabel = Instance.new("ImageLabel")
	local TextLabel = Instance.new("TextLabel")
	
	Frame.Parent = OBack
	Frame.BackgroundColor3 = Color3.new(1, 1, 1)
	Frame.BackgroundTransparency = 1
	Frame.Size = UDim2.new(0, 175, 0, 200)
	
	ImageLabel.Parent = Frame
	ImageLabel.BackgroundColor3 = Color3.new(1, 1, 1)
	ImageLabel.BackgroundTransparency = 1
	ImageLabel.BorderSizePixel = 0
	ImageLabel.Position = UDim2.new(0.0971428454, 0, 0.0650000051, 0)
	ImageLabel.Size = UDim2.new(0.800000012, 0, 0.800000012, 0)
	ImageLabel.SizeConstraint = Enum.SizeConstraint.RelativeXX
	ImageLabel.Image = "rbxthumb://type=Outfit&id="..Id.."&w=150&h=150"
	
	TextLabel.Parent = Frame
	TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Position = UDim2.new(0, 0, 1, 0)
	TextLabel.Size = UDim2.new(1, 0, -0.25, 0)
	TextLabel.Font = Enum.Font.Code
	TextLabel.Text = Name
	TextLabel.TextColor3 = Color3.new(1, 1, 1)
	TextLabel.TextSize = 18
	TextLabel.TextStrokeTransparency = 0
end

function addToContextMenu(text, callback, func)
	local TextButton = Instance.new("TextButton")
	TextButton.Parent = bruh
	TextButton.BackgroundColor3 = UI.colors.tabselected
	TextButton.BorderColor3 = UI.colors.outline
	TextButton.Size = UDim2.new(0, 200, 0, 25)
	TextButton.AutoButtonColor = false
	TextButton.Font = Enum.Font.Code
	TextButton.Text = text
	TextButton.TextColor3 = Color3.new(1, 1, 1)
	TextButton.TextSize = 14
	TextButton.TextStrokeTransparency = 0
	TextButton.ZIndex = 70
	
	bruh:GetPropertyChangedSignal("Visible"):connect(function()
		if bruh.Visible and func then
			func(ClickedName, TextButton)
		end
	end)
	
	TextButton.MouseButton1Down:Connect(function()
		callback(ClickedName)
	end)
	
	TextButton.MouseEnter:Connect(function()
		TextButton.BackgroundColor3 = UI.colors.theme
	end)
	
	TextButton.MouseLeave:Connect(function()
		TextButton.BackgroundColor3 = UI.colors.tabselected
	end)
end

function getSite()
	local SpawnPoints = workspace.Map.SpawnPoints
	local HRPPos = Local.Player.Character.HumanoidRootPart.Position
    if GetDistanceSq(HRPPos, SpawnPoints.C4Plant.Position) <
        GetDistanceSq(HRPPos, SpawnPoints.C4Plant2.Position) then
        return "B"
    else
        return "A"
    end
end

Services.UserInputService.InputBegan:connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		bruh.Visible = false
	end
	if input.KeyCode == Enum.KeyCode.Space then
		repeat
			wait(1)
			Storage.AutohopHit = math.random() < Settings.AutohopHitrate/100
		until not Services.UserInputService:IsKeyDown(Enum.KeyCode.Space) or Storage.AutohopHit == false
	end
end)

Local.Mouse.Button1Down:connect(function()
	local Character = Local.Player.Character
	if isAlive(Local.Player) and Character.EquippedTool.Value == "R8" and Character:FindFirstChild("Gun") and Settings.InstaRev then
		Local.Game.firebullet(true)
	end
end)

function AddSkin(v, s)
	local Client = Local.PlayerGui.Client
	local Color
	local Rarity
	if Client.Rarities:FindFirstChild(s) then
		Rarity = Client.Rarities[s].Value
		Color = Client.Colors[Rarity].Value
	else
		Rarity = "UNKNOWN"
		Color = Color3.fromRGB(132, 129, 122)
	end
	
	local Template = Instance.new("ImageButton")
	local UIListLayout_4 = Instance.new("UIListLayout")
	local Rarity_2 = Instance.new("TextLabel")
	local Status_2 = Instance.new("TextLabel")
	local Team_2 = Instance.new("TextLabel")
	local Username_2 = Instance.new("TextLabel")

	Template.Name = "Template"
	Template.BackgroundColor3 = UI.colors.theme
	Template.BorderSizePixel = 0
	Template.LayoutOrder = Order[Rarity]
	Template.BackgroundTransparency = 1
	Template.Size = UDim2.new(1, 0, 0, 20)
	Template.ImageTransparency = 1
	Template.AutoButtonColor = false
	Template.Parent = SBack

	UIListLayout_4.Parent = Template
	UIListLayout_4.FillDirection = Enum.FillDirection.Horizontal
	UIListLayout_4.SortOrder = Enum.SortOrder.LayoutOrder
	
	Status_2.Name = "Using"
	Status_2.Parent = Template
	Status_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Status_2.BackgroundTransparency = 1
	Status_2.BorderColor3 = Color3.new(0, 0, 0)
	Status_2.BorderSizePixel = 0
	Status_2.LayoutOrder = 4
	Status_2.Size = UDim2.new(0.333, 0, 1, 0)
	Status_2.Font = Enum.Font.SourceSans
	Status_2.Text = "false"
	Status_2.TextColor3 = Color3.new(1, 1, 1)
	Status_2.TextSize = 14

	Rarity_2.Name = "Rarity"
	Rarity_2.Parent = Template
	Rarity_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Rarity_2.BackgroundTransparency = 1
	Rarity_2.BorderColor3 = Color3.new(0, 0, 0)
	Rarity_2.BorderSizePixel = 0
	Rarity_2.LayoutOrder = 3
	Rarity_2.Size = UDim2.new(0.333, 0, 1, 0)
	Rarity_2.Font = Enum.Font.SourceSans
	Rarity_2.Text = Rarity
	Rarity_2.TextColor3 = Color3.new(1, 1, 1)
	Rarity_2.TextSize = 14
	
	Team_2.Name = "Skin"
	Team_2.Parent = Template
	Team_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Team_2.BackgroundTransparency = 1
	Team_2.LayoutOrder = 2
	Team_2.BorderColor3 = Color3.new(0, 0, 0)
	Team_2.BorderSizePixel = 0
	Team_2.Size = UDim2.new(0.333, 0, 1, 0)
	Team_2.Font = Enum.Font.SourceSans
	Team_2.Text = s
	Team_2.TextColor3 = Color
	Team_2.TextSize = 14
	
	SkinScroll.CanvasSize = UDim2.new(0,0,0,SBackList.AbsoluteContentSize.Y)

	Template.MouseButton1Click:Connect(function()
		for i,v in pairs(SBack:GetChildren()) do
			if v:IsA("ImageButton") then
				if v.BackgroundColor3 ~= Color3.fromRGB(112, 111, 211) then
					v.BackgroundTransparency = 1
				end
			end
		end
		if Template.BackgroundColor3 == Color3.fromRGB(112, 111, 211) then
			Template.BackgroundTransparency = 1
			Template.BackgroundColor3 = UI.colors.theme
			Status_2.Text = "false"
			local weapon = string.split(s, "_")
			FESkins[weapon[1]] = nil
			SkinClicked = nil
			return
		end
		Template.BackgroundTransparency = 0
		Template.BackgroundColor3 = UI.colors.theme
		if SkinClicked == s then
			Template.BackgroundColor3 = Color3.fromRGB(112, 111, 211)
			local weapon = string.split(s, "_")
			if FESkins[weapon[1]] then
				FESkins[weapon[1]][2].BackgroundTransparency = 1
				FESkins[weapon[1]][2].BackgroundColor3 = UI.colors.theme
				FESkins[weapon[1]][2].Using.Text = "false"
			end
			FESkins[weapon[1]] = {v.Name, Template, weapon[2], Color}
			Status_2.Text = "true"
		end
		SkinClicked = s
	end)

	table.insert(PlayerListInfo[v.UserId].Skins, Template)
end

function AddPlayer(v)
	
	local thumbnail, isready = Services.Players:GetUserThumbnailAsync(v.UserId, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size100x100)
	local bust, isready = Services.Players:GetUserThumbnailAsync(v.UserId, Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size100x100)
	local headshot, isready = Services.Players:GetUserThumbnailAsync(v.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
	
	local Template = Instance.new("ImageButton")
	local UIListLayout_4 = Instance.new("UIListLayout")
	local Age_2 = Instance.new("TextLabel")
	local Status_2 = Instance.new("TextLabel")
	local Team_2 = Instance.new("TextLabel")
	local Username_2 = Instance.new("TextLabel")
	
	local pictures = {
		thumbnail, bust, headshot
	}
	
	local AC = v.AccountAge
	Template.Name = "Template"
	Template.Parent = Back
	Template.BackgroundColor3 = UI.colors.theme
	Template.BorderSizePixel = 0
	Template.LayoutOrder = ((v:WaitForChild("Status").Team.Value == "T") and 0) or 1 -- Terrorists go first, then cts
	Template.BackgroundTransparency = 1
	Template.Size = UDim2.new(1, 0, 0, 20)
	Template.ImageTransparency = 1
	Template.AutoButtonColor = false

	UIListLayout_4.Parent = Template
	UIListLayout_4.FillDirection = Enum.FillDirection.Horizontal
	UIListLayout_4.SortOrder = Enum.SortOrder.LayoutOrder
	
	Age_2.Name = "Age"
	Age_2.Parent = Template
	Age_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Age_2.BackgroundTransparency = 1
	Age_2.BorderColor3 = Color3.new(0, 0, 0)
	Age_2.BorderSizePixel = 0
	Age_2.LayoutOrder = 3
	Age_2.Size = UDim2.new(0.200000003, 0, 1, 0)
	Age_2.Font = Enum.Font.SourceSans
	Age_2.Text = AC.." days"
	Age_2.TextColor3 = Color3.new(1, 1, 1)
	Age_2.TextSize = 14
	
	Status_2.Name = "Status"
	Status_2.Parent = Template
	Status_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Status_2.BackgroundTransparency = 1
	Status_2.BorderColor3 = Color3.new(0, 0, 0)
	Status_2.BorderSizePixel = 0
	Status_2.LayoutOrder = 2
	Status_2.Size = UDim2.new(0.200000003, 0, 1, 0)
	Status_2.Font = Enum.Font.SourceSans
	Status_2.Text = "Auto"
	Status_2.TextColor3 = Color3.new(1, 1, 1)
	Status_2.TextSize = 14
	
	Team_2.Name = "Team"
	Team_2.Parent = Template
	Team_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Team_2.BackgroundTransparency = 1
	Team_2.BorderColor3 = Color3.new(0, 0, 0)
	Team_2.BorderSizePixel = 0
	Team_2.Size = UDim2.new(0.300000012, 0, 1, 0)
	Team_2.Font = Enum.Font.SourceSans
	Team_2.Text = v.Team.Name
	Team_2.TextColor3 = v.Team.TeamColor.Color 
	Team_2.TextSize = 14
	
	Username_2.Name = "Username"
	Username_2.Parent = Template
	Username_2.BackgroundColor3 = Color3.new(0.227451, 0.227451, 0.227451)
	Username_2.BackgroundTransparency = 1
	Username_2.BorderColor3 = Color3.new(0, 0, 0)
	Username_2.BorderSizePixel = 0
	Username_2.LayoutOrder = 1
	Username_2.Size = UDim2.new(0.300000012, 0, 1, 0)
	Username_2.Font = Enum.Font.SourceSans
	Username_2.Text = v.Name
	Username_2.TextColor3 = Color3.new(1, 1, 1)
	Username_2.TextSize = 14
	
	SFrame.CanvasSize = UDim2.new(0,0,0,UIListLayout_3.AbsoluteContentSize.Y)
	
	PlayerListInfo[v.UserId].Object = Template

	v:GetPropertyChangedSignal("Team"):connect(function()
		for i,v in pairs(PlayerListInfo[v.UserId].Skins) do
			v:Destroy()
		end
		doSkins(v, false)
		Template.LayoutOrder = ((v.Status.Team.Value == "T") and 0) or 1
		Team_2.Text = v.Team.Name
		Team_2.TextColor3 = v.Team.TeamColor.Color 
	end)
	
	local function selected()
		local count = 1
		for i,v in pairs(Pictures.content:GetChildren()) do
			if v:IsA("ImageLabel") then
				v.Image = pictures[count]
				count = count + 1
			end
		end
		for i,v in pairs(Back:GetChildren()) do
			if v:IsA("ImageButton") then
				v.BackgroundTransparency = 1
			end
		end
		Template.BackgroundTransparency = 0
		Name.label.Text = "Name: "..v.Name
		UID.label.Text = "UserID: "..v.UserId
		RGroup.label.Text = "Is in ROLVe Group: "..tostring(v:IsInGroup(2613928))
		Funds.label.Text = "Credits: "..v.SkinFolder.Funds.Value
		Tier.label.Text = "Current Battlepass Tier: "..v.Tiers.Value
		LOM.label.Text = "Legit-o-meter: "..((v.Tiers.Value*9) + v.AccountAge*.3)/10000
		local floor = math.floor
		local deg = math.deg
		repeat 
			wait()
			IAlive.label.Text = "Is Alive: "..tostring(v.Character ~= nil)
			Cash.label.Text = "Cash: "..v.Cash.Value
			local pos = v.CameraCF.Value.p
			local x, y, z = floor(pos.x), floor(pos.y), floor(pos.z)
			Pos.label.Text = "Position: ("..x..", "..y..", "..z..")"
			local angles = v.CameraCF.Value.lookVector
			local rx, ry, rz = floor(deg(angles.x)), floor(deg(angles.y)), floor(deg(angles.z))
			Ang.label.Text = "Angles: ("..rx..", "..ry..", "..rz..")"
		until ClickedName.UserId ~= v.UserId
	end
	
	Template.MouseButton2Click:Connect(function()
		bruh.Position = UDim2.new(0, Local.Mouse.X, 0, Local.Mouse.Y)
		ClickedName = v
		bruh.Visible = true
		selected()
	end)
	
	Template.MouseButton1Click:Connect(function()
		ClickedName = v
		selected()
	end)
end

addToContextMenu("Aimbot Rage", function(v)
	PlayerListInfo[v.UserId].Status = "Rage"
	PlayerListInfo[v.UserId].Object.Status.Text = "Rage"
	PlayerListInfo[v.UserId].Object.Status.TextColor3 = Color3.new(1,0,0)
end)

addToContextMenu("Aimbot Auto", function(v)
	PlayerListInfo[v.UserId].Status = "Auto"
	PlayerListInfo[v.UserId].Object.Status.Text = "Auto"
	PlayerListInfo[v.UserId].Object.Status.TextColor3 = Color3.new(1,1,1)
end)

addToContextMenu("Aimbot Legit", function(v)
	PlayerListInfo[v.UserId].Status = "Legit"
	PlayerListInfo[v.UserId].Object.Status.Text = "Legit"
	PlayerListInfo[v.UserId].Object.Status.TextColor3 = Color3.new(1,1,0)
end)

addToContextMenu("Aimbot Friend", function(v)
	PlayerListInfo[v.UserId].Status = "Friend"
	PlayerListInfo[v.UserId].Object.Status.Text = "Friend"
	PlayerListInfo[v.UserId].Object.Status.TextColor3 = Color3.new(0,1,0)
end)

addToContextMenu("Prevent from living", function(v)
	if PlayerListInfo[v.UserId].Kill then
		PlayerListInfo[v.UserId].Kill:disconnect()
		PlayerListInfo[v.UserId].Kill = nil
		return
	end
	
	PlayerListInfo[v.UserId].Kill = S:connect(function()
		if isAlive(v) and isAlive(Local.Player) then
			for i = 1,100 do
				local Arguments = {
					[1] = v.Character.Head,
					[2] = v.Character.Head.Position,
					[3] = "Karambit",
					[4] = math.huge,
					[5] = Local.Player.Character.Gun,
					[8] = 999,
					[10] = true,
					[11] = Local.Camera.CFrame.p,
					[12] = workspace.DistributedTime.Value,
					[13] = Vector3.new(),
				}
				Events.HitPart:FireServer(unpack(Arguments))
			end
		end
	end)
end, function(v, t)
	if PlayerListInfo[v.UserId].Kill then
		t.Text = "Allow to live"
	else
		t.Text = "Prevent from living"
	end
end)

addToContextMenu("Spam character sounds", function(v)
	PlayerListInfo[v.UserId].Sounds = not PlayerListInfo[v.UserId].Sounds or true
	local function applyHook(c)
		c:WaitForChild("EquippedTool"):GetPropertyChangedSignal("Value"):connect(function()
			if PlayerListInfo[v.UserId].Sounds then
				for i,v in pairs(v.Character:GetDescendants()) do
					if v:isA("Sound") then
						v.Looped = true
						v.Playing = true
					end
				end
			end
		end)
	end
	if PlayerListInfo[v.UserId].Sounds then
		v.CharacterAdded:connect(function(c)
			applyHook(c)
		end)
		if isAlive(v) then
			applyHook(v.Character)
		end
	end
end, function(v, t)
	if PlayerListInfo[v.UserId].Sounds then
		t.Text = "Stop spamming sounds"
	else
		t.Text = "Spam character sounds"
	end
end)

addToContextMenu("Spam sounds to them only", function(v)
	if PlayerListInfo[v.UserId].Whizz then
		PlayerListInfo[v.UserId].Whizz:disconnect()
		PlayerListInfo[v.UserId].Whizz = nil
		return
	end

	PlayerListInfo[v.UserId].Whizz = S:connect(function()
		Whizz(v)
	end)
end, function(v, t)
	if PlayerListInfo[v.UserId].Whizz then
		t.Text = "Stop spamming sounds"
	else
		t.Text = "Spam sounds to them only"
	end
end)

addToContextMenu("Make them vomit weapons", function(v)
	if not PlayerListInfo[v.UserId].Drop then
		PlayerListInfo[v.UserId].Drop = true

		while PlayerListInfo[v.UserId].Drop do
			for i,w in pairs(Weapons.Path:GetChildren()) do
				if w:IsA("Folder") then
					wait()
					DropGun(w, v.CameraCF.Value, nil)
				end
			end
		end
	else
		PlayerListInfo[v.UserId].Drop = false
	end
end, function(v, t)
	if PlayerListInfo[v.UserId].Drop then
		t.Text = "Stop dropping weapons"
	else
		t.Text = "Make them vomit weapons"
	end
end)

addToContextMenu("Stand on head", function(v)
	local function disconnect()
		if PlayerListInfo[v.UserId].Stand then
			PlayerListInfo[v.UserId].Stand:disconnect()
			PlayerListInfo[v.UserId].Stand = nil
			return
		end
	end
	disconnect()

	PlayerListInfo[v.UserId].Stand = S:connect(function()
		if isAlive(Local.Player) and isAlive(v) then
			Local.Player.Character.HumanoidRootPart.CustomPhysicalProperties = PhysicalProperties.new(0, 0, 0)
			Local.Player.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame * CFrame.new(0, 6, 0)
			if v.Character.Humanoid.Health == 0 then
				disconnect()
			end
			if Local.Player.Character.Humanoid.Jump == true then
				disconnect()
			end
		end
	end)
end, function(v, t)
	if PlayerListInfo[v.UserId].Stand then
		t.Text = "Stop standing on them"
	else
		t.Text = "Stand on head"
	end
end)

addToContextMenu("Teleport to", function(v)
	if isAlive(Local.Player) and isAlive(v) then
		Local.Player.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame
	end
end)


UI.base.DisplayOrder = 8

function leavePlayer(v)
	if PlayerListInfo[v.UserId] then
		if PlayerListInfo[v.UserId].Kill then
			PlayerListInfo[v.UserId].Kill:disconnect()
			PlayerListInfo[v.UserId].Kill = nil
		end
		
		if PlayerListInfo[v.UserId].Whizz then
			PlayerListInfo[v.UserId].Whizz:disconnect()
			PlayerListInfo[v.UserId].Whizz = nil
		end

		for i,v in pairs(PlayerListInfo[v.UserId].Skins) do
			v:Destroy()
		end

		PlayerListInfo[v.UserId].Object:Destroy()
	end
	if SpectateEntries[v.Name] then
		SpectateEntries[v.Name]:Destroy()
		SpectateEntries[v.Name] = nil
	end
end

Local.Player:WaitForChild("DamageLogs").ChildAdded:Connect(function(hit)
	local DMG = hit:WaitForChild("DMG")
	local lastdmg = 0
	local function HitHook()
		OnHit(hit.Name, DMG.Value-lastdmg)
		lastdmg = DMG.Value
		if Settings.Killsay then
			if Services.Players[hit.Name].Status.Alive.Value then
				Services.Players[hit.Name].Status.Alive:GetPropertyChangedSignal("Value"):Wait()
			end
			Chat(Settings.Chat2:gsub("{}", hit.Name))
		end
	end
	HitHook()
	DMG:GetPropertyChangedSignal("Value"):Connect(function()
		HitHook()
	end)
end)

function doSkins(v, added)
	local team = v:WaitForChild("Status"):WaitForChild("Team").Value
	if team == "Spectator" then return end
	local SkinF = v:WaitForChild("SkinFolder"):WaitForChild(team.."Folder")
	local function doAdd(s)
		if s.Value ~= "Stock" and s.Value:len() > 0 and s.Name ~= "Glove" then
			AddSkin(v, s.Name.."_"..s.Value)
		end
	end
	if added then
		for i,s in pairs(SkinF:GetChildren()) do
			doAdd(s)
		end
	else
		SkinF.ChildAdded:connect(function(s)
			doAdd(s)
		end)
	end
end

function createDot()
	local d = Drawing.new("Circle")
	d.NumSides = 15
	d.Radius = 5
	d.Filled = true
	d.Color = Color3.new(1, 1, 1)
	return d
end

function createText(v)
	local d = Drawing.new("Text")
	d.Text = v.Name
	d.Size = 14
	d.Center = true
	d.Outline = true
	d.Color = Color3.new(1, 1, 1)
	return d
end

local function create_line()
	local Line = Drawing.new("Line")
	Line.Thickness = 1
	Line.Transparency = 1
	return Line
end

local function create_text()
	local name = Drawing.new("Text")
	name.Size = 14
	name.Center = false
	name.Outline = true
	name.Transparency = 1
	return name
end


function newPlayer(v, added)
	spawn(function()
		AddPlayer(v)
	end)
	local PlayerEntry = Top:Clone()
	PlayerEntry.Visible = false
	PlayerEntry.Name = v.Name
	PlayerEntry.Spec.Text = v.Name
	PlayerEntry.Parent = SpecF
	SpectateEntries[v.Name] = PlayerEntry
	PlayerListInfo[v.UserId] = {}
	PlayerListInfo[v.UserId].Skins = {}
	PlayerListInfo[v.UserId].Status = "Auto"
	PlayerListInfo[v.UserId].SpectatorDot = createDot()
	PlayerListInfo[v.UserId].SpectatorText = createText(v)
	v:WaitForChild("Status"):WaitForChild("Alive")

	local tracer = create_line()
	local name = create_text()
	local weapon = create_text()
	local bomb = create_text()
    local up = create_line()
    local down = create_line()
    local left = create_line()
	local right = create_line()
	
	local function disable()
		tracer.Visible = false
		name.Visible = false
		weapon.Visible = false
		up.Visible = false
		down.Visible = false
		left.Visible = false
		right.Visible = false
		bomb.Visible = false
	end

	local player = v
	
	PlayerListInfo[v.UserId].DrawingAPI = S:connect(function()
		if player and player.Team and player.Team ~= Local.Player.Team and player.Character and player.Character:FindFirstChildOfClass("Humanoid") and player.Character.Humanoid.Health > 0 then
			local allCorners = {}
			for _,v in pairs(player.Character:GetChildren()) do
				if v:isA("BasePart") then
					local a = AimbotFunctions.getCorners(v.CFrame, v.Size)
					for _,v in pairs(a) do
						table.insert(allCorners, v)
					end
				end
			end

			local xMin = Local.Camera.ViewportSize.X
			local yMin = Local.Camera.ViewportSize.Y
			local xMax = 0
			local yMax = 0

			for i,v in pairs(allCorners) do
				local pos, ons = Local.Camera:WorldToViewportPoint(v)
				if not ons then
					return disable()
				end
				if pos.X > xMax then
					xMax = pos.X
				end
				if pos.X < xMin then
					xMin = pos.X
				end
				if pos.Y > yMax then
					yMax = pos.Y
				end
				if pos.Y < yMin then
					yMin = pos.Y
				end
			end

			local info = Vector2.new(xMax + 3, yMin)

			if (Settings.Boxes.Allies.Enabled and v.Team == Local.Player.Team) or (Settings.Boxes.Enemies.Enabled and v.Team ~= Local.Player.Team) then
				local Color = (Settings.Boxes.Allies.Color and v.Team == Local.Player.Team) or Settings.Boxes.Enemies.Color
				local Transparency = 1-((Settings.Boxes.Allies.Transparency and v.Team == Local.Player.Team) or Settings.Boxes.Enemies.Transparency)
				up.Visible = true
				down.Visible = true
				left.Visible = true
				right.Visible = true
				tracer.Visible = true
				up.From = Vector2.new(xMin, yMin)
				up.To = Vector2.new(xMax, yMin)
				down.From = Vector2.new(xMin, yMax)
				down.To = Vector2.new(xMax, yMax)
				left.From = Vector2.new(xMin, yMin)
				left.To = Vector2.new(xMin, yMax)
				right.From = Vector2.new(xMax, yMin)
				right.To = Vector2.new(xMax, yMax)
				up.Color = Color
				down.Color = Color
				left.Color = Color
				right.Color = Color
				up.Transparency = Transparency
				down.Transparency = Transparency
				left.Transparency = Transparency
				right.Transparency = Transparency
			else
				up.Visible = false
				down.Visible = false
				left.Visible = false
				right.Visible = false
			end

			if (Settings.Nametags.Allies.Enabled and v.Team == Local.Player.Team) or (Settings.Nametags.Enemies.Enabled and v.Team ~= Local.Player.Team) then
				name.Visible = true
				name.Position = info
				name.Text = player.Name
				name.Transparency = 1-((Settings.Nametags.Allies.Transparency and v.Team == Local.Player.Team) or Settings.Nametags.Enemies.Transparency)
				name.Color = (Settings.Nametags.Allies.Color and v.Team == Local.Player.Team) or Settings.Nametags.Enemies.Color
			else
				name.Visible = false
			end
            
			local point, vis = Local.Camera:WorldToViewportPoint(player.Character.PrimaryPart.Position)
			if vis and (Settings.WeaponText.Allies.Enabled and v.Team == Local.Player.Team) or (Settings.WeaponText.Enemies.Enabled and v.Team ~= Local.Player.Team) then
				weapon.Visible = true
				weapon.Position = info + Vector2.new(0, 16)
				weapon.Text = tostring(player.Character.EquippedTool.Value)
				weapon.Transparency = 1-((Settings.WeaponText.Allies.Transparency and v.Team == Local.Player.Team) or Settings.WeaponText.Enemies.Transparency)
				weapon.Color = (Settings.WeaponText.Allies.Color and v.Team == Local.Player.Team) or Settings.WeaponText.Enemies.Color
			else
				weapon.Visible = false
			end
			
			local point, vis = Local.Camera:WorldToViewportPoint(player.Character.PrimaryPart.Position)
			if vis and (Settings.BombText.Allies.Enabled and v.Team == Local.Player.Team) or (Settings.BombText.Enemies.Enabled and v.Team ~= Local.Player.Team)and workspace.Status.HasBomb.Value == player.Name then
				bomb.Visible = true
				bomb.Position = info + Vector2.new(0, 32)
				bomb.Text = "Bomb"
				bomb.Transparency = 1-((Settings.BombText.Allies.Transparency and v.Team == Local.Player.Team) or Settings.BombText.Enemies.Transparency)
				bomb.Color = (Settings.BombText.Allies.Color and v.Team == Local.Player.Team) or Settings.BombText.Enemies.Color
			else
				bomb.Visible = false
            end

			if (Settings.Tracers.Allies.Enabled and v.Team == Local.Player.Team) or (Settings.Tracers.Enemies.Enabled and v.Team ~= Local.Player.Team) then
				local half = (xMax-xMin)/2
				tracer.Visible = true
				tracer.From = Vector2.new(Local.Camera.ViewportSize.X/2, Local.Camera.ViewportSize.Y)
				tracer.To = Vector2.new(xMin+half, yMax)
				tracer.Transparency = 1-((Settings.Tracers.Allies.Transparency and v.Team == Local.Player.Team) or Settings.Tracers.Enemies.Transparency)

				tracer.Color = (Settings.Tracers.Allies.Color and v.Team == Local.Player.Team) or Settings.Tracers.Enemies.Color
			else
				tracer.Visible = false
			end
		else
			disable()
		end
	end)
	
	doSkins(v, added)
end

S:connect(function()
	for i,v in pairs(Services.Players:GetPlayers()) do
		local addTargets = addTargets
		local Mouse = Local.Mouse
		local stat = getStatus(v)
		if stat == "Friend" then return end
		stat = Settings[stat]
		if stat.DetectionMethod == "All Threats (360°)" then
			if isAlive(v) and v.Team ~= Local.Player.Team then
				local Threat = CalculateThreat(v)
				if Threat then
					table.insert(Storage.Targets, v)
					return
				end
			end
		end
	end
end)

S:connect(function()
	if Settings.AA.Enabled and Local.Player.Character and Local.Player.Character:FindFirstChild("HumanoidRootPart") and Local.Player.Character:FindFirstChild("Humanoid") then
		Local.Player.Character.Humanoid.AutoRotate = false
		local HRP = Local.Player.Character.HumanoidRootPart
		if JNegative then
			Jitter = (Jitter - Settings.AA.JSpeed) % (Settings.AA.JRange+1)
		else
			Jitter = (Jitter + Settings.AA.JSpeed) % (Settings.AA.JRange+1)
		end
		local Offset
		if JRotation then
			Offset = CFrame.Angles(0,-math.rad(Jitter),0)
		else
			Offset = CFrame.Angles(0,math.rad(Jitter),0)
		end
		
		if Settings.AA.Direction == "Manual" then
			Quarter = math.pi / 2
			if Direction == "Left" then
				HRP.CFrame = CFrame.new(HRP.CFrame.p) * CFrame.Angles(0, Quarter*3, 0) * Offset
			elseif Direction == "Back" then
				HRP.CFrame = CFrame.new(HRP.CFrame.p) * CFrame.Angles(0, Quarter*2, 0) * Offset
			elseif Direction == "Right" then
				HRP.CFrame = CFrame.new(HRP.CFrame.p) * CFrame.Angles(0, Quarter, 0) * Offset
			else
				Local.Player.Character.Humanoid.AutoRotate = true
			end
		elseif Settings.AA.Direction ~= "None" then
			local ohn = CalculateAntiAngles(Settings.AA.Pitch > 1)
			if ohn then
				HRP.CFrame = ohn * Offset
			end
		else
			HRP.CFrame = CFrame.new(HRP.CFrame.p) * Offset
		end
	end
end)

Local.Player:WaitForChild("KarmaDone"):Destroy()

Services.Players.PlayerAdded:Connect(newPlayer)
Services.Players.PlayerRemoving:Connect(leavePlayer)

Services.Lighting.LightingChanged:connect(function()
	Services.Lighting.GlobalShadows = false
end)

function checkForSkybox(v)
	if v:IsA("Sky") and v ~= Skybox then
		v:Destroy()
	end
end

Services.Lighting.ChildAdded:connect(function(v)
	checkForSkybox(v)
end)

for i,v in pairs(Services.Lighting:GetDescendants()) do
	checkForSkybox(v)
end

game.Close:connect(Save)	

for i,v in pairs(Services.Players:GetPlayers()) do
	newPlayer(v, true)
end
