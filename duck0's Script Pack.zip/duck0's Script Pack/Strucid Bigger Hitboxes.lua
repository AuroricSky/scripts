--[[https://v3rmillion.net/showthread.php?tid=1005783, Strucid body size changer or bigger hitboxes by payk12
**EXECUTE THE STRUCID ANTI-BAN SCRIPT BEFORE THIS**
]]
S = Vector3.new(20, 20, 20)
Players = game:GetService("Players")
meta = getrawmetatable(game)
id = meta.__index
make_writeable(meta)

function GetF(Tab)
return id(Tab.script, "Parent")
end
function GetThing(Par, Nam)
    return id(Par, Nam)
end

meta.__index = newcclosure(function(rc, ...)
args = {...}
if GetF(getfenv(2)) == nil then
return id(rc, unpack(args))
end
if rc:IsA("BasePart")  and args[1] == "Size" and Players:FindFirstChild(tostring(GetThing(rc, "Parent"))) then
return Vector3.new(0.1, 0.1, 0.1)
end
return id(rc, ...)
end)

while wait(1) do
    for i, v in pairs(Players:GetPlayers()) do
        if v ~= Players.LocalPlayer and (Players.LocalPlayer.Team == nil or Players.LocalPlayer.Team ~= v.Team) and v.Character ~= nil then
            for a, b in pairs(v.Character:GetChildren()) do
                if b:IsA("BasePart") then
                    b.Size = S
                end
            end
        end
    end
end
