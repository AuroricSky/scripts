--[[https://v3rmillion.net/showthread.php?tid=1015352, 4th reply, Server Hop Script by Renchi.
]]
local id = tonumber(game.PlaceId)

game:GetService("TeleportService"):Teleport(id, game:GetService("Players").LocalPlayer)