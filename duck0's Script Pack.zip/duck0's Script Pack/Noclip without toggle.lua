--source: https://pastebin.com/YqCND4QS made by me @duck0#0001.
loadstring(game.HttpGet(game, "https://pastebin.com/raw/YqCND4QS")) ()