--[[https://v3rmillion.net/showthread.php?tid=1012112, FE Animations Hub by Stormy420.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/RbQDmVuR",true))()