--[[ vote for map disable:
]]
votemenu = game.Players.LocalPlayer.PlayerGui.MainGui.MapVotePage

votemenu.Visible=false