--[[https://v3rmillion.net/showthread.php?tid=1009076, KAT Knife-Aura by null.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/5rukLQcj", true))()