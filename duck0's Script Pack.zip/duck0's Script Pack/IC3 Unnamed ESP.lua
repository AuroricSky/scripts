--[[https://github.com/ic3w0lf22/Unnamed-ESP, IC3 unnamed esp by ic3w0lf22.
this is the way better one synapse x has in its script hub.
]]
loadstring(game:HttpGet('https://raw.githubusercontent.com/ic3w0lf22/Unnamed-ESP/master/UnnamedESP.lua'))()