--[[source: https://v3rmillion.net/showthread.php?tid=1018908
Green Hub by GreenedBoi.
this hub isn't even green lol.
]]
loadstring(game:HttpGet(('https://raw.githubusercontent.com/mememasterboi/a-lot-of-scripts/master/Green%20Hub'),true))()